#!/usr/bin/env python3
"""Inspect NES CHR storage and optionally visualize raw PRG as unverified tiles.

Examples:
    python3 tools/extract_chr.py 'Prince of Persia (USA).zip'
    python3 tools/extract_chr.py 'Prince of Persia (USA).zip' --scan-prg

Only a declared CHR-ROM region is exported as CHR. PRG diagnostic sheets are
explicitly unverified: code, compressed data, and tables may look like patterns.
No game palettes, sprite groupings, or screen layouts are inferred.
"""

import argparse
import hashlib
import json
from pathlib import Path
import struct
import zipfile
import zlib


PALETTE = (0, 85, 170, 255)
SOURCES = [
    "https://www.nesdev.org/wiki/NES_2.0",
    "https://www.nesdev.org/wiki/PPU_pattern_tables",
]


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def load_rom(path, member=None):
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as archive:
            members = [n for n in archive.namelist() if n.lower().endswith(".nes")]
            if member is None:
                if len(members) != 1:
                    raise ValueError("ZIP must contain exactly one .nes file, or use --member")
                member = members[0]
            return archive.read(member), member
    if member is not None:
        raise ValueError("--member is only valid with a ZIP input")
    return path.read_bytes(), None


def rom_size(low, high, unit):
    if high == 15:
        return (1 << (low >> 2)) * (2 * (low & 3) + 1)
    return ((high << 8) | low) * unit


def ram_size(shift):
    return (64 << shift) if shift else 0


def parse_header(data):
    if len(data) < 16 or data[:4] != b"NES\x1a":
        raise ValueError("Input does not have a valid 16-byte iNES magic/header")
    h = data[:16]
    nes2 = h[7] & 12 == 8
    if not nes2 and h[7] & 12:
        raise ValueError("Unsupported reserved/archaic header format")
    trainer_size = 512 if h[6] & 4 else 0
    prg_size = rom_size(h[4], h[9] & 15, 16384) if nes2 else h[4] * 16384
    chr_size = rom_size(h[5], h[9] >> 4, 8192) if nes2 else h[5] * 8192
    prg_start = 16 + trainer_size
    chr_start = prg_start + prg_size
    expected_end = chr_start + chr_size
    if expected_end > len(data):
        raise ValueError(f"Header declares {expected_end} bytes, but file has {len(data)}")
    return {
        "header_hex": h.hex(" "),
        "format": "NES 2.0" if nes2 else "iNES 1.0",
        "mapper": (h[6] >> 4) | (h[7] & 240) | ((h[8] & 15) << 8 if nes2 else 0),
        "submapper": h[8] >> 4 if nes2 else None,
        "trainer_size_bytes": trainer_size,
        "prg_rom_size_bytes": prg_size,
        "prg_rom_file_offset": prg_start,
        "chr_rom_size_bytes": chr_size,
        "chr_rom_file_offset": chr_start if chr_size else None,
        "chr_ram_size_bytes": ram_size(h[11] & 15) if nes2 else None,
        "chr_nvram_size_bytes": ram_size(h[11] >> 4) if nes2 else None,
        "trailing_size_bytes": len(data) - expected_end,
    }


def decode_tile(tile):
    """8x8 pixel indices; bit 7 is left; first 8 bytes are the low plane."""
    if len(tile) != 16:
        raise ValueError("A tile must contain exactly 16 bytes")
    return [
        ((tile[y] >> (7 - x)) & 1) | (((tile[y + 8] >> (7 - x)) & 1) << 1)
        for y in range(8) for x in range(8)
    ]


def png_chunk(kind, data):
    return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data))


def write_sheet(path, data, label):
    """PNG pixel data needs only stdlib; installed Pillow adds visible labels."""
    count = len(data) // 16
    if not count:
        raise ValueError("Cannot render an empty tile sheet")
    columns = 32
    rows = (count + columns - 1) // columns
    scale = 2
    width, height = columns * 8 * scale, rows * 8 * scale
    pixels = bytearray(width * height)
    for t in range(count):
        indices = decode_tile(data[t * 16:t * 16 + 16])
        for y in range(8):
            for x in range(8):
                intensity = PALETTE[indices[y * 8 + x]]
                px, py = ((t % columns) * 8 + x) * scale, ((t // columns) * 8 + y) * scale
                for dy in range(scale):
                    pixels[(py + dy) * width + px:(py + dy) * width + px + scale] = bytes([intensity]) * scale
    annotation = label + "; DIAGNOSTIC GRAYSCALE 0=0 1=85 2=170 3=255; NOT GAME COLORS"
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        # Labels remain in the filename, PNG text chunk, and companion JSON.
        png = b"\x89PNG\r\n\x1a\n"
        png += png_chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 0, 0, 0, 0))
        png += png_chunk(b"tEXt", b"Description\x00" + annotation.encode("latin1"))
        scanlines = b"".join(b"\0" + pixels[y * width:(y + 1) * width] for y in range(height))
        png += png_chunk(b"IDAT", zlib.compress(scanlines, 9))
        png += png_chunk(b"IEND", b"")
        path.write_bytes(png)
        visible_label_height = 0
    else:
        from PIL.PngImagePlugin import PngInfo
        visible_label_height = 52
        image = Image.new("L", (width, height + visible_label_height), 24)
        image.paste(Image.frombytes("L", (width, height), bytes(pixels)), (0, visible_label_height))
        draw = ImageDraw.Draw(image)
        for y, line in zip((3, 19, 35), (label, "DIAGNOSTIC GRAYSCALE: 0=0 1=85 2=170 3=255", "UNVERIFIED RAW INTERPRETATION; NOT GAME COLORS")):
            draw.text((4, y), line, fill=255)
        info = PngInfo()
        info.add_text("Description", annotation)
        image.save(path, pnginfo=info)
    return {
        "file": path.name,
        "png_sha256": sha256(path.read_bytes()),
        "source_sha256": sha256(data),
        "source_size_bytes": len(data),
        "tile_count": count,
        "ignored_partial_tile_bytes": len(data) % 16,
        "columns": columns,
        "rows": rows,
        "pixel_scale": scale,
        "visible_label_height_pixels": visible_label_height,
        "tile_file_offset_formula": "source_file_offset + 16 * (row * columns + column)",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--member", help="Exact .nes ZIP member when ambiguous")
    parser.add_argument("--output", type=Path, default=Path("analysis/graphics"))
    parser.add_argument("--scan-prg", action="store_true", help="Render raw PRG banks as UNVERIFIED 2bpp diagnostics")
    args = parser.parse_args()
    data, member = load_rom(args.input, args.member)
    header = parse_header(data)
    args.output.mkdir(parents=True, exist_ok=True)
    result = {
        "input_file": args.input.name,
        "input_file_sha256": sha256(args.input.read_bytes()),
        "zip_member": member,
        "rom_size_bytes": len(data),
        "rom_sha256": sha256(data),
        "header": header,
        "palette": {"type": "diagnostic grayscale; not original game colors", "pixel_index_to_gray": list(PALETTE)},
        "tile_decode": {"tile_size_bytes": 16, "width": 8, "height": 8,
                        "low_bitplane_byte_offsets": "0..7, one per row",
                        "high_bitplane_byte_offsets": "8..15, one per row",
                        "horizontal_bit_order": "bit 7 is leftmost",
                        "pixel_index_formula": "((byte[y] >> (7-x)) & 1) | (((byte[y+8] >> (7-x)) & 1) << 1)"},
        "chr_rom_exports": [],
        "unverified_prg_diagnostics": [],
        "limitations": [
            "Header-declared CHR-RAM is runtime memory, not a CHR-ROM file region.",
            "Raw PRG tile interpretation does not establish graphics boundaries or identify code versus data.",
            "Compressed graphics and graphics with different layouts will not be decoded by this diagnostic.",
            "No runtime CHR-RAM captures, original palettes, sprite grouping, or gameplay screen layouts were recovered.",
        ],
        "format_references": SOURCES,
    }
    chr_size = header["chr_rom_size_bytes"]
    if chr_size:
        start = header["chr_rom_file_offset"]
        chr_data = data[start:start + chr_size]
        (args.output / "chr_rom.bin").write_bytes(chr_data)
        for bank, offset in enumerate(range(0, chr_size, 8192)):
            sheet = write_sheet(args.output / f"chr_rom_bank_{bank:03d}_diagnostic_grayscale.png", chr_data[offset:offset + 8192], f"CHR-ROM BANK {bank:03d}; FILE {start + offset:#07x}")
            sheet["source_file_offset"] = start + offset
            result["chr_rom_exports"].append(sheet)
        result["status"] = "Declared CHR-ROM extracted; palette and grouping remain unknown"
    else:
        result["status"] = "No CHR-ROM declared; no CHR binary or authentic CHR sheet exported"
    if args.scan_prg:
        start = header["prg_rom_file_offset"]
        for bank, offset in enumerate(range(0, header["prg_rom_size_bytes"], 16384)):
            end = min(offset + 16384, header["prg_rom_size_bytes"])
            sheet = write_sheet(args.output / f"unverified_prg_bank_{bank:02d}_diagnostic_grayscale.png", data[start + offset:start + end], f"UNVERIFIED PRG BANK {bank:02d}; FILE {start + offset:#07x}")
            sheet.update({"source_file_offset": start + offset,
                          "source_file_offset_end_exclusive": start + end,
                          "classification": "unverified raw PRG bytes interpreted as consecutive 2bpp tiles"})
            result["unverified_prg_diagnostics"].append(sheet)
    (args.output / "metadata.json").write_text(json.dumps(result, indent=2) + "\n")
    print(result["status"])
    print(f"PRG diagnostics: {len(result['unverified_prg_diagnostics'])}; metadata: {args.output / 'metadata.json'}")


if __name__ == "__main__":
    main()
