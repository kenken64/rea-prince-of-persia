/** Original-ROM observation only. This module is never imported by the C/Wasm game. */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {NES, Controller} from '../analysis/validation/original-ledge-emulator/node_modules/jsnes/src/index.js';

export const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
export const out=path.join(root,'analysis/validation');
export const romPath=path.join(root,'analysis/rom/Prince of Persia (USA).nes');
export const rom=fs.readFileSync(romPath);
export const digest=crypto.createHash('sha256').update(rom).digest('hex');
if(digest!=='5f14d4d31cc588ddcdfb2b4d46eb7051b06d02655c9208037ef7ae137c4740e4')throw Error('Unexpected ROM');
export {Controller};

export function makeNES(){
  let buffer=null;
  const nes=new NES({emulateSound:false,onFrame(frame){buffer=Uint32Array.from(frame);},onStatusUpdate(){}});
  nes.loadROM(rom);
  nes.observationFrame=0;
  nes.observationBuffer=()=>buffer;
  return nes;
}
export function state(nes){
  const m=nes.cpu.mem;
  return {frame:nes.observationFrame,pc:(nes.cpu.REG_PC+1)&65535,level:m[0x70],room_index:m[0x51],
    input:m[0x40a],previous_input:m[0x37],intro:m[0x735],demo:m[0x4e4],
    actor_x:m[0x60f]|m[0x610]<<8,actor_y:m[0x611],script:m[0x613]|m[0x614]<<8,
    direction_raw:m[0x615],action:m[0x616],metasprite:m[0x617],motion_mode_raw:m[0x618],alive_raw:m[0x618],graphic_id:m[0x600],
    actor_raw:Array.from(m.slice(0x60e,0x62c)),zp_0c_7f:Array.from(m.slice(12,128))};
}
export function buttons(nes,names=[]){
  for(const name of ['A','B','SELECT','START','UP','DOWN','LEFT','RIGHT']){
    const key=Controller['BUTTON_'+name];
    if(names.includes(name))nes.buttonDown(1,key);else nes.buttonUp(1,key);
  }
}
export function step(nes,count=1,names=[],trace=null){
  buttons(nes,names);
  for(let i=0;i<count;i++){nes.frame();nes.observationFrame++;if(trace)trace.push(state(nes));}
  return state(nes);
}
export function saveFrame(nes,name){
  const pixels=nes.observationBuffer();if(!pixels)return null;
  const bytes=Buffer.alloc(256*240*3);
  // JSNES2.1 framebuffer stores RGB with red in the low byte.
  for(let i=0;i<pixels.length;i++){bytes[i*3]=pixels[i]&255;bytes[i*3+1]=(pixels[i]>>8)&255;bytes[i*3+2]=(pixels[i]>>16)&255;}
  const target=path.join(out,'original-ledge-'+name+'.ppm');
  fs.writeFileSync(target,Buffer.concat([Buffer.from('P6\n256 240\n255\n'),bytes]));return target;
}
export function saveState(nes,name){
  const target=path.join(out,'original-ledge-'+name+'.state.json');fs.writeFileSync(target,JSON.stringify(nes.toJSON()));return target;
}
export function loadState(nes,name){nes.fromJSON(JSON.parse(fs.readFileSync(path.join(out,'original-ledge-'+name+'.state.json'))));return nes;}

if(process.argv[1]===fileURLToPath(import.meta.url)){
  const nes=makeNES(),trace=[];
  step(nes,180,[],trace);saveFrame(nes,'boot180');
  step(nes,2,['START'],trace);step(nes,180,[],trace);saveFrame(nes,'start362');
  step(nes,2,['START'],trace);step(nes,300,[],trace);saveFrame(nes,'start664');saveState(nes,'boot');
  fs.writeFileSync(path.join(out,'original-ledge-boot-trace.json'),JSON.stringify({rom_sha256:digest,emulator:'jsnes2.1.0',rom_mutated:false,trace},null,2));
  console.log(JSON.stringify(trace.filter((v,i)=>i%30===0).map(({zp_0c_7f,actor_raw,...v})=>v),null,2));
}
