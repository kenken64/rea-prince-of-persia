#!/usr/bin/env python3
"""Extract exact NES Prince of Persia room bytes, links, spawns and events.

No game engine or emulator is used.  The format was independently checked against
the supplied ROM after using NESPrincEd's author's article as a format reference:
https://habr.com/en/post/192028/
All offsets in output JSON refer to the complete, 16-byte-headered .nes file.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import struct
from collections import Counter, deque

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_ROM = ROOT / "analysis/rom/Prince of Persia (USA).nes"
DEFAULT_OUT = ROOT / "analysis/levels"
EXPECTED_SHA256 = "5f14d4d31cc588ddcdfb2b4d46eb7051b06d02655c9208037ef7ae137c4740e4"
POINTER_TABLES = {"tiles": 0x1EB4A, "header": 0x1EB66, "links": 0x1EB82}
SOURCE = "https://habr.com/en/post/192028/"
# These meanings are explicitly described in the reference article. Other types
# remain numeric; importing the DOS tile list would silently assume port parity.
TYPE_NAMES = {0: "empty", 1: "floor", 3: "pillar", 4: "gate", 20: "solid wall"}
DIRECTIONS = ("left", "right", "up", "down")


def check(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def cpu_to_file(address: int) -> int:
    check(0x8000 <= address < 0xC000, f"Pointer outside bank 6: ${address:04X}")
    return 16 + 6 * 16384 + address - 0x8000


def coordinates(rooms: list[dict], start_room: int) -> tuple[dict, list]:
    """Find a schematic embedding; retain inconsistent links rather than repair."""
    coords, conflicts = {}, []
    deltas = ((-1, 0), (1, 0), (0, -1), (0, 1))
    for seed in [start_room] + list(range(1, 25)):
        if seed in coords or not rooms[seed - 1]["present"]:
            continue
        max_x = max((v[0] for v in coords.values()), default=-3)
        coords[seed] = (max_x + 3, 0) if coords else (0, 0)
        queue = deque([seed])
        while queue:
            room = queue.popleft()
            x, y = coords[room]
            for d, neighbor in enumerate(rooms[room - 1]["links_raw"]):
                if not neighbor or not rooms[neighbor - 1]["present"]:
                    continue
                target = (x + deltas[d][0], y + deltas[d][1])
                if neighbor not in coords:
                    coords[neighbor] = target
                    queue.append(neighbor)
                elif coords[neighbor] != target:
                    conflicts.append({"room": room, "direction": DIRECTIONS[d],
                                      "target": neighbor, "expected": target,
                                      "already_at": coords[neighbor]})
    return {str(k): list(v) for k, v in coords.items()}, conflicts


def extract(rom: bytes) -> dict:
    check(rom[:4] == b"NES\x1a", "Expected NES file signature")
    check(len(rom) == 131088 and rom[4] == 8 and rom[5] == 0,
          "This extractor supports the exact 8-bank, CHR-RAM USA ROM layout")
    check(not (rom[6] & 4), "Trainer layouts are unsupported")
    sha256 = hashlib.sha256(rom).hexdigest()
    check(sha256 == EXPECTED_SHA256,
          f"ROM SHA256 differs from the verified input ({sha256}); refusing fixed offsets")
    pointers = {name: list(struct.unpack_from("<14H", rom, offset))
                for name, offset in POINTER_TABLES.items()}
    levels, histogram = [], Counter()
    roundtrip_spans = []
    for idx in range(14):
        number = idx + 1
        offsets = {name: cpu_to_file(values[idx]) for name, values in pointers.items()}
        cursor = offsets["tiles"]
        rooms = []
        encoded_tiles = bytearray()
        for room in range(1, 25):
            start = cursor
            present = rom[cursor] != 0xFF
            length = 30 if present else 1
            raw = list(rom[cursor:cursor + length]) if present else []
            check(len(raw) == 30 if present else True, f"Level{number} truncated room{room}")
            encoded_tiles.extend(raw if present else [255])
            cursor += length
            links = list(rom[offsets["links"] + (room - 1) * 4:
                             offsets["links"] + room * 4])
            check(all(0 <= value <= 24 for value in links), f"Bad room link in level{number}")
            histogram.update(value & 31 for value in raw)
            rooms.append({"id": room, "present": present, "file_offset": start,
                          "encoded_length": length, "tiles_raw": raw,
                          "tile_types": [v & 31 for v in raw],
                          "tile_modifiers": [v >> 5 for v in raw],
                          "links_raw": links,
                          "links": dict(zip(DIRECTIONS, links))})
        check(cursor == offsets["links"], f"Level{number} room boundary mismatch")
        check(offsets["header"] - offsets["links"] == 96,
              f"Level{number} geometry/header boundary mismatch")
        check(encoded_tiles == rom[offsets["tiles"]:cursor], "Room byte roundtrip failed")
        header = list(rom[offsets["header"]:offsets["header"] + 27])
        check(1 <= header[0] <= 24 and 0 <= header[1] < 30,
              f"Invalid spawn in level{number}")
        check(header[2] in (0, 255), f"Unknown initial direction in level{number}")
        for room, guard in zip(rooms, header[3:]):
            pos = guard & 31
            room["guard_raw"] = guard
            room["guard_position"] = pos if pos < 30 else None
            room["guard_high_bits"] = guard >> 5
        cursor = offsets["header"] + 27
        events_start = cursor
        events = []
        limit = cpu_to_file(pointers["tiles"][idx + 1]) if idx < 13 else 0x1AA20
        while cursor < limit and rom[cursor] != 255:
            values = list(rom[cursor:cursor + 5])
            check(len(values) == 5, f"Truncated event level{number}")
            a, b, c, d, e = values
            check(1 <= a <= 24 and b < 30 and c in (0, 1) and 1 <= d <= 24 and e < 30,
                  f"Invalid event at file offset0x{cursor:X}")
            events.append({"file_offset": cursor, "source_room": a, "source_position": b,
                           "action_raw": c, "action": "close" if c else "open",
                           "target_room": d, "target_position": e, "raw": values})
            cursor += 5
        check(cursor < limit and rom[cursor] == 255, f"Missing event terminator level{number}")
        event_terminator = cursor
        cursor += 1
        # Bytes after FF are padding/stale data, NOT additional active events.
        padding_end = limit if idx < 13 else 0x1AA20
        padding = list(rom[cursor:padding_end])
        check(len(events) <= 32, "Increase C event capacity")
        reconstructed = (bytes(encoded_tiles) +
                         bytes(value for room in rooms for value in room["links_raw"]) +
                         bytes(header) + bytes(value for event in events for value in event["raw"]) +
                         b"\xff" + bytes(padding))
        check(reconstructed == rom[offsets["tiles"]:padding_end],
              f"Level{number} complete data byte roundtrip failed")
        level = {"number": number, "level_index": idx,
                 "theme_raw": rom[0x1EB05 + idx],
                 "theme": "palace" if rom[0x1EB05 + idx] else "dungeon",
                 "pointers_cpu_bank6": {k: pointers[k][idx] for k in pointers},
                 "file_offsets": {**offsets, "events": events_start,
                                  "event_terminator": event_terminator},
                 "start": {"room": header[0], "position": header[1],
                           "column": header[1] % 10, "row": header[1] // 10,
                           "direction_raw": header[2],
                           "direction": -1 if header[2] == 255 else 1},
                 "rooms": rooms, "events": events,
                 "after_event_terminator_raw": padding,
                 "after_event_terminator_file_offset": cursor}
        level["schematic_coordinates"], level["schematic_conflicts"] = coordinates(rooms, header[0])
        levels.append(level)
        roundtrip_spans.append({"level": number, "file_offset": offsets["tiles"],
                                "end_exclusive": cursor,
                                "sha256": hashlib.sha256(rom[offsets["tiles"]:cursor]).hexdigest(),
                                "room_encoding_roundtrip": True,
                                "complete_encoding_roundtrip_with_padding": True})
    return {"schema": "pop-nes-verified-levels-v1", "rom_sha256": sha256,
            "format_reference": SOURCE, "pointer_tables_file_offsets": POINTER_TABLES,
            "bank": 6, "bank_cpu_base": 0x8000, "rooms_per_level": 24,
            "room_columns": 10, "room_rows": 3, "tile_type_mask": 31,
            "tile_modifier_shift": 5,
            "tile_names_confirmed_in_reference": TYPE_NAMES,
            "tile_type_histogram": dict(sorted(histogram.items())),
            "validation": {"all_14_room_stream_boundaries_match_geometry": True,
                           "all_14_geometry_blocks_are_96_bytes": True,
                           "all_room_streams_roundtrip_exactly": True,
                           "all_complete_level_data_roundtrips_exactly": True,
                           "all_events_valid_and_ff_terminated": True,
                           "spans": roundtrip_spans},
            "limitations": ["Tile names beyond the explicit reference descriptions remain numeric.",
                            "Upper three tile bits are retained; only gate modifier0/1 is named.",
                            "Guard upper bits are retained without assigning semantics.",
                            "Nonreciprocal room links and inaccessible rooms are preserved.",
                            "Level-specific scripted events live in code and are not encoded here.",
                            "This is data recovery, not proof of gameplay-equivalent C code."],
            "levels": levels}


def write_header(data: dict, path: Path) -> None:
    lines = ["/* Generated by tools/extract_levels.py from the verified user-supplied ROM.",
             f" * ROM SHA256: {data['rom_sha256']}",
             " * Rooms and links use ORIGINAL room IDs1..24; link0 means outside.",
             " * Tiles remain raw bytes: type=byte&31, modifier=byte>>5.",
             " * start_direction is normalized -1=left,+1=right; guard retains raw bits.",
             " * Absent rooms have present=0 and an all-zero expanded tiles entry.",
             " * Events: action0=open,1=close. Only entries below event_count are active.",
             " * Original gameplay scripts are not reconstructed by this data header. */",
             "#ifndef POP_NES_LEVEL_DATA_H", "#define POP_NES_LEVEL_DATA_H", "#include <stdint.h>",
             "enum { LEVEL_COUNT=14, LEVEL_ROOM_COUNT=24, LEVEL_ROOM_TILES=30, LEVEL_MAX_EVENTS=32 };",
             "typedef struct { uint8_t source_room, source_position, action, target_room, target_position; } LevelEvent;",
             "typedef struct {", "    uint8_t tiles[24][30];", "    uint8_t links[24][4];",
             "    uint8_t guard[24];", "    uint8_t present[24];",
             "    uint8_t start_room, start_pos;", "    int8_t start_direction;",
             "    uint8_t theme, event_count;", "    LevelEvent events[32];", "} LevelData;",
             "static const LevelData levels[14] = {"]
    for level in data["levels"]:
        lines.extend([f"  {{ /* Level {level['number']} */", "    .tiles = {"])
        for room in level["rooms"]:
            raw = room["tiles_raw"] if room["present"] else [0] * 30
            lines.append("      {" + ",".join(f"0x{v:02x}" for v in raw) + f"}}, /* room{room['id']} */")
        lines.extend(["    },", "    .links = {"])
        for room in level["rooms"]:
            lines.append("      {" + ",".join(map(str, room["links_raw"])) + "},")
        lines.extend(["    },", "    .guard = {" + ",".join(str(r["guard_raw"]) for r in level["rooms"]) + "},",
                      "    .present = {" + ",".join(str(int(r["present"])) for r in level["rooms"]) + "},",
                      f"    .start_room={level['start']['room']}, .start_pos={level['start']['position']},",
                      f"    .start_direction={level['start']['direction']}, .theme={level['theme_raw']}, .event_count={len(level['events'])},",
                      "    .events = {"])
        for event in level["events"]:
            lines.append("      {" + ",".join(map(str, event["raw"])) + "},")
        lines.extend(["    }", "  },"])
    lines.extend(["};", "#endif", ""])
    path.write_text("\n".join(lines))


def write_svg(level: dict, path: Path) -> None:
    """A card atlas preserves every numbered room without inventing geography."""
    colors = ["#172331", "#9c9384", "#913f44", "#777d94", "#a9804e", "#37596c"]
    parts = ['<svg xmlns="http://www.w3.org/2000/svg" width="1260" height="1150" viewBox="0 0 1260 1150">',
             '<rect width="1260" height="1150" fill="#0a1019"/>',
             '<style>text{font-family:monospace;fill:#dbe4ef} .small{font-size:11px} .title{font-size:24px}</style>',
             f'<text class="title" x="24" y="36">Prince of Persia NES · Level{level["number"]} · {level["theme"]}</text>',
             '<text class="small" x="24" y="59">Raw tile type IDs in hex · modifier shown after : · room IDs and links remain original</text>']
    for i, room in enumerate(level["rooms"]):
        x, y = 24 + (i % 4) * 310, 80 + (i // 4) * 175
        links = room["links_raw"]
        parts.append(f'<text x="{x}" y="{y}">Room{room["id"]:02} · L{links[0]} R{links[1]} U{links[2]} D{links[3]}</text>')
        if not room["present"]:
            parts.append(f'<text class="small" x="{x+8}" y="{y+42}">Absent (single FF marker)</text>')
            continue
        for pos, raw in enumerate(room["tiles_raw"]):
            tx, ty = x + pos % 10 * 28, y + 12 + pos // 10 * 34
            typ, mod = raw & 31, raw >> 5
            fill = colors[0] if typ == 0 else colors[1] if typ == 1 else colors[2] if typ == 20 else colors[3] if typ == 3 else colors[4] if typ == 4 else colors[5]
            parts.append(f'<rect x="{tx}" y="{ty}" width="27" height="33" fill="{fill}" stroke="#263347"/>')
            parts.append(f'<text class="small" x="{tx+2}" y="{ty+20}">{typ:02X}:{mod}</text>')
        guard = room["guard_position"]
        start = f' · Prince@{level["start"]["position"]}' if level["start"]["room"] == room["id"] else ""
        parts.append(f'<text class="small" x="{x}" y="{y+129}">Guard: {guard if guard is not None else "none"}{start}</text>')
        parts.append(f'<text class="small" x="{x}" y="{y+145}">ROM0x{room["file_offset"]:05X}</text>')
    parts.append('</svg>')
    path.write_text("\n".join(parts))


def write_index(data: dict, path: Path) -> None:
    rows = []
    for level in data["levels"]:
        n = level["number"]
        rows.append(f'<tr><td>{n}</td><td>{level["theme"]}</td>'
                    f'<td>{sum(r["present"] for r in level["rooms"])}</td>'
                    f'<td>{len(level["events"])}</td>'
                    f'<td>room{level["start"]["room"]}, position{level["start"]["position"]}</td>'
                    f'<td><a href="level-{n:02}.svg">Room atlas</a> · '
                    f'<a href="level-{n:02}.json">JSON</a></td></tr>')
    document = '''<!doctype html><html lang="en"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Recovered Prince of Persia NES level data</title>
<style>body{font:16px system-ui,sans-serif;background:#101722;color:#e5ecf5;margin:40px auto;padding:0 20px;max-width:1050px;line-height:1.55}
a{color:#8cbfff}table{border-collapse:collapse;width:100%}td,th{padding:10px;text-align:left;border-bottom:1px solid #324054}code{overflow-wrap:anywhere}</style>
<h1>Recovered Prince of Persia NES level data</h1>
<p>Fourteen levels, 271 present rooms and 146 active door events, extracted directly from the supplied ROM. Each room atlas shows the original tile bytes as type:modifier, all 24 room slots, links and guard positions.</p>
<p><a href="levels.json">All level JSON</a> · <a href="level_data.h">Editable C data header</a> · <a href="validation.json">Validation evidence</a> · <a href="FORMAT.txt">Format and evidence</a></p>
<table><thead><tr><th>Level</th><th>Theme</th><th>Rooms</th><th>Events</th><th>Spawn</th><th>Data</th></tr></thead><tbody>
''' + "\n".join(rows) + '''</tbody></table>
<p>The atlases use schematic colors and numeric tile types. They are data inspection views, not reconstructed game screenshots. Unknown tile modifier meanings and code-defined story sequences remain documented in the format notes.</p>
<p>Format reference: <a href="https://habr.com/en/post/192028/">Alexander/loginsin, NESPrincEd, chapter3</a>. Exact ROM bytes and boundaries are validated independently by the extractor.</p>
</html>'''
    path.write_text(document)


def write_format(data: dict, path: Path) -> None:
    lines = ["PRINCE OF PERSIA NES USA: RECOVERED LEVEL FORMAT", "",
             "Reproduce: python3 tools/extract_levels.py", "",
             f"Verified complete ROM SHA256: {data['rom_sha256']}",
             "The extractor refuses other ROM hashes because all offsets are revision-specific.", "",
             "Byte/format evidence:",
             "- NESPrincEd author Alexander/loginsin describes the format in chapter3:",
             SOURCE,
             "- All three pointer tables in this exact ROM match the documented positions.",
             "- Fixed bank7 code C0C7/C0DA/C0E8 selects these tables; C0D5 doubles RAM70's level index.",
             "- 6502 CPU addresses in bank6 map to file16+6*16384+(address-0x8000).",
             "- Every one of the14 room-stream end positions exactly equals its geometry pointer.",
             "- All14 geometry blocks end at their header after exactly96 bytes.",
             "- All14 room streams re-encode byte-for-byte; every event stream has an FF terminator.", "",
             "Pointer tables (14 little-endian16-bit addresses each):",
             "rooms: file0x1EB4A / CPU0xEB3A; headers: file0x1EB66 / CPU0xEB56;",
             "geometry: file0x1EB82 / CPU0xEB72. All targets are in selected PRG bank6.", "",
             "For each of24 room IDs1..24:",
             "- If first byte is FF, room is absent and consumes one byte.",
             "- Otherwise consume30 tile bytes, row-major10 columns x3 rows.",
             "- Tile type=byte&31; modifier=byte>>5. Retain raw bytes when editing.",
             "Geometry:24 records of4 bytes (left,right,up,down). Room0 means no neighbor.",
             "Header: start_room,start_position,start_direction,24 raw guard bytes.",
             "Positions are row*10+column. FF start_direction means left;00 means right.",
             "Guard position=raw&31; values30/31 mean absent. Upper3 bits are not assigned a meaning.",
             "After the header, consume5-byte door events until first FF:",
             "source_room,source_position,action(0=open/1=close),target_room,target_position.",
             "Bytes following the first FF are preserved as unused/stale bytes, never active events.", "",
             "C integration:",
             "level_data.h defines LevelData, LevelEvent and static const LevelData levels[14].",
             "tiles[24][30] are raw bytes. present[24] distinguishes absent expanded-zero rooms.",
             "links[24][4] retains original1-based IDs,0=outside; do not reinterpret0 as room1.",
             "guard[24] retains raw values. start_direction alone is normalized to-1/+1.",
             "events[32] is bounded by event_count. theme0=dungeon,theme1=palace.", "",
             "Tile semantic confidence:",
             "Explicitly described in NESPrincEd article:0 empty,1 floor,3 pillar,4 gate,20 wall.",
             "Article gives gate04 closed/24 open; raw gate44 and higher modifiers also occur.",
             "Data corroborates15 raise and6 drop: most corresponding event sources use these types.",
             "All25 type16 cells immediately precede type17; exit halves are an inference.",
             "Unique type22 is level1 room15 position22, beside type21. Sword/skeleton is an inference.",
             "Unique type13 is level4 room4 position4, modifier5. Mirror is an inference.",
             "Other standard-port type-name guesses are deliberately not assigned in JSON/header.", "",
             "Limits:",
             "- Byte extraction proves data recovery; independent C gameplay still needs behavior validation.",
             "- Level1/6/7/12/13/14 entry/exit story rules and other scripts also live in executable code.",
             "- A room graph may be nonreciprocal or lack a consistent2D embedding (notably levels6,10).",
             "  Original links are retained, and schematic coordinate conflicts are explicitly recorded.",
             "- Some defined events refer to absent rooms or nonbutton cells. They are preserved exactly.",
             "- SVG atlas colors are inspection aids, not original graphics or palette evidence.", "",
             "Level summary:",
             "level present_rooms events room_file_offset geometry_file_offset header_file_offset"]
    for level in data["levels"]:
        o = level["file_offsets"]
        lines.append(f"{level['number']:2} {sum(r['present'] for r in level['rooms']):2} {len(level['events']):2} "
                     f"0x{o['tiles']:05X} 0x{o['links']:05X} 0x{o['header']:05X}")
    path.write_text("\n".join(lines) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", type=Path, default=DEFAULT_ROM)
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT)
    args = parser.parse_args()
    data = extract(args.rom.read_bytes())
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "levels.json").write_text(json.dumps(data, indent=2) + "\n")
    write_header(data, args.out / "level_data.h")
    write_index(data, args.out / "index.html")
    write_format(data, args.out / "FORMAT.txt")
    for level in data["levels"]:
        basename = f"level-{level['number']:02}"
        (args.out / f"{basename}.json").write_text(json.dumps(level, indent=2) + "\n")
        write_svg(level, args.out / f"{basename}.svg")
    summary = {"levels": len(data["levels"]),
               "present_rooms": sum(r["present"] for l in data["levels"] for r in l["rooms"]),
               "active_events": sum(len(l["events"]) for l in data["levels"]),
               "rom_sha256": data["rom_sha256"], "validation": data["validation"]}
    (args.out / "validation.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({k: v for k, v in summary.items() if k != "validation"}, indent=2))


if __name__ == "__main__":
    main()
