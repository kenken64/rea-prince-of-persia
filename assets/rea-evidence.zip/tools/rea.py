#!/usr/bin/env python3
"""Run the installed Rea with this investigation's scoped Ghidra/JDK selection."""
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent.parent
environment = dict(os.environ)
location = root / "analysis/tooling/ghidra-location.json"
if "GHIDRA_INSTALL_DIR" not in environment and location.exists():
    environment["GHIDRA_INSTALL_DIR"] = json.loads(location.read_text())["path"]
if "JAVA_HOME" not in environment and Path("/usr/libexec/java_home").exists():
    found = subprocess.run(["/usr/libexec/java_home", "-v", "21"], capture_output=True, text=True)
    if found.returncode == 0:
        environment["JAVA_HOME"] = found.stdout.strip()
raise SystemExit(subprocess.call(["rea", *sys.argv[1:]], cwd=root, env=environment))
