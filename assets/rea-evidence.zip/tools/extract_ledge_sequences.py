#!/usr/bin/env python3
"""Decode the original USA NES ledge animation VM into reproducible step tables.

This traces bytecode and nominal anchor changes, not cosmetic interpolation.
FB movement can be blocked by the original FE25/FE44 collision predicates;
external actor controllers can replace a script between these logical steps.
"""
import json
from pathlib import Path
import hashlib

ROOT = Path(__file__).resolve().parent.parent
ROM = ROOT / "analysis/rom/Prince of Persia (USA).nes"
EXPECTED = "5f14d4d31cc588ddcdfb2b4d46eb7051b06d02655c9208037ef7ae137c4740e4"


def extract():
    rom = ROM.read_bytes()
    assert hashlib.sha256(rom).hexdigest() == EXPECTED
    bank = rom[16 + 5 * 16384:16 + 6 * 16384]

    def byte(pc):
        assert 0x8000 <= pc < 0xC000
        return bank[pc - 0x8000]

    def word(pc):
        return byte(pc) | byte(pc + 1) << 8

    def decode(name, action, stop_frame=None, limit=150):
        start = word(0x95F2 + 2 * action)
        pc, dx, dy, mode = start, 0, 0, 0xFF
        steps, commands, seen = [], [], set()
        pending = []
        for _ in range(1000):
            if pc in seen and not pending:
                break
            seen.add(pc)
            at, op = pc, byte(pc)
            if op < 0xF1:
                steps.append({"step": len(steps), "pc": pc, "file_offset": 16 + 5 * 16384 + pc - 0x8000,
                              "frame": op, "dx_right": dx, "dy": dy, "mode": mode,
                              "action": action, "commands_before": pending})
                pending = []
                pc += 1
                if stop_frame is not None and op == stop_frame:
                    break
                if len(steps) >= limit:
                    break
                continue
            event = {"pc": pc, "opcode": op}
            pc += 1
            if op == 0xFF:
                target = word(pc)
                event.update(kind="jump", target=target)
                pc = target
            elif op == 0xFB:
                raw = byte(pc)
                factor = 1 if action in (5, 11) else 2
                if mode == 2:
                    factor *= 2
                encoded = (raw * factor) & 255
                # This is the original one's-complement horizontal convention.
                delta = encoded if encoded < 0x7F else -(255 - encoded)
                dx += delta
                event.update(kind="horizontal", argument=raw, factor=factor, encoded=encoded,
                             delta_right=delta, conditional="Original FE44/FE25 may block player X movement")
                pc += 1
            elif op == 0xFA:
                raw = byte(pc)
                delta = raw if raw < 0x7F else raw - 256
                dy += delta
                event.update(kind="vertical", argument=raw, delta=delta)
                pc += 1
            elif op == 0xF9:
                mode = byte(pc)
                event.update(kind="motion_mode", value=mode)
                pc += 1
            elif op == 0xF8:
                event.update(kind="fall_state_reset", arguments=[byte(pc), byte(pc + 1)],
                             ram06da=2 * byte(pc), ram06db=104)
                pc += 2
            elif op == 0xF5:
                # F1C0 advances before dispatch; F180 advances after dispatch.
                # Unlike zero-argument handlers,85BD does not DEC21. Therefore
                # it consumes/discards the following byte (e.g. frame148).
                event.update(kind="clear_fall_flags", discarded_byte=byte(pc))
                pc += 1
            elif op in (0xFC, 0xFD, 0xF4):
                event.update(kind={0xFC: "edge_flag_reset", 0xFD: "ledge_flag_reset", 0xF4: "land_flags"}[op])
            elif op == 0xF2:
                event.update(kind="sound_event", argument=byte(pc))
                pc += 1
            else:
                raise ValueError(f"unhandled opcode{op:02X} at{at:04X} for{name}")
            commands.append(event)
            pending.append(event)
        return {"name": name, "action": action, "script_cpu_address": start,
                "script_file_offset": 16 + 5 * 16384 + start - 0x8000,
                "steps": steps, "commands": commands,
                "continuation_pc": pc, "source_bank": 5}

    sequences = {
        "catch": decode("catch", 9, stop_frame=91),
        "climb": decode("climb", 10, stop_frame=15),
        "lower": decode("lower", 0x44, stop_frame=91),
        "hang_swing": decode("hang_swing", 9, stop_frame=15),
        "pullback": decode("pullback", 11, stop_frame=15),
        "letgo": decode("letgo", 0x17, limit=5),
    }
    result = {
        "rom_sha256": EXPECTED,
        "classification": "Original animation bytecode frame order and nominal anchor deltas; no interpolated poses",
        "selector": {"cpu_address": 0x8730, "bank": 5, "pointer_table_cpu_address": 0x95F2,
                     "action_ram": 0x0616, "script_pointer_ram": [0x0613, 0x0614]},
        "vm": {"cpu_address": 0xF13E, "fixed_bank": 7,
               "opcode_dispatch_table": 0x842B, "frame_ram": 0x0617,
               "anchor_x_ram": [0x060F, 0x0610], "anchor_y_ram": 0x0611,
               "mode_ram": 0x0618, "right_facing": "0615nonzero; verified by original-ROM RIGHT-input runtime trace",
               "logical_step": "F13E consumes commands until one literal frame0..F0, then stores frame/pointer and renders actor",
               "cadence": "Original-ROM runtime verified one logical step per4video frames in the controlled level1 no-guard climb; other scheduling contexts remain unverified"},
        "sequences": sequences,
        "important": [
            "Climb consumesF5's following byte148 as an unused argument: rendered frames135..147,149,15.",
            "Climb FA C1 moves original anchor UP63px before frame141; this cancels its frame-origin discontinuity.",
            "Lower FA3F moves anchor DOWN63px before frame140; inverse compensation is required.",
            "Lower's final frame91 is still mode1; following F902 changes mode2 before continuing at98A8/frame90.",
            "98A5 hang_swing is FINITE and eventually jumps992D thenstanding96DB. It is not a proven stable idle loop.",
            "Controllers can interrupt or replace scripts, snap anchors, or block FB movement; tables alone do not reconstruct those conditions.",
            "letgo action17/script993B reaches repeated frame106 with fall mode4; ongoing gravity is external to this bytecode table.",
            "All DX values use original right-facing0615nonzero. Left-facing DX is the negative; Y is unchanged."],
        "evidence": [
            "analysis/rea/ledge-vm-f13e.json", "analysis/rea/ledge-command-fb.json",
            "analysis/rea/ledge-command-fa.json", "analysis/rea/ledge-command-f9.json",
            "analysis/rea/ledge-command-f8.json", "analysis/rea/ledge-command-fc.json",
            "analysis/rea/ledge-command-fd.json", "analysis/rea/ledge-command-f4.json",
            "analysis/rea/ledge-command-f5.json", "analysis/rea/ledge-subtract-x.json",
            "analysis/rea/ledge-add-x.json"],
        "limitations": ["No stable hang-loop hold behavior is assumed.",
                        "Original controller snaps and collision predicates are outside this bytecode-only extraction.",
                        "No original-ROM pixel changes or synthetic gameplay-room data are introduced."]}
    return result


def write_header(data, path):
    lines = ["/* Generated by tools/extract_ledge_sequences.py from the original USA ROM.",
             " * dx_right/dy are accumulated ORIGINAL actor-anchor deltas, not tweens.",
             " * One row is one logical animation VM step; cadence is separately verified.",
             " * FB X deltas are nominal: original collision predicates can block them.",
             " * hang_swing is finite, not a proven idle loop. */",
             "#ifndef POP_ORIGINAL_LEDGE_SEQUENCES_H", "#define POP_ORIGINAL_LEDGE_SEQUENCES_H", "#include <stdint.h>",
             "typedef struct { int16_t dx_right, dy; uint16_t pc; uint8_t frame, mode, action; } PopLedgeStep;"]
    for name, seq in data["sequences"].items():
        lines.append(f"static const PopLedgeStep pop_ledge_{name}[] = {{")
        for step in seq["steps"]:
            lines.append("    {%d,%d,0x%04x,%d,%d,0x%02x}," %
                         (step["dx_right"], step["dy"], step["pc"], step["frame"], step["mode"], step["action"]))
        lines += ["};", f"enum {{ POP_LEDGE_{name.upper()}_COUNT = {len(seq['steps'])} }};"]
    lines += ["#endif", ""]
    path.write_text("\n".join(lines))


if __name__ == "__main__":
    data = extract()
    out = ROOT / "analysis/rea/ledge-sequences.json"
    out.write_text(json.dumps(data, indent=2) + "\n")
    header = ROOT / "analysis/graphics/ledge_sequences.h"
    write_header(data, header)
    print(json.dumps({name: [(s["frame"], s["dx_right"], s["dy"], s["mode"]) for s in seq["steps"]]
                      for name, seq in data["sequences"].items()}))
