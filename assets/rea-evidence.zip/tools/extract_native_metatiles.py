#!/usr/bin/env python3
"""Recover base background compositions using the original tables/6502 loader.

Rea/Ghidra traces E0C4, E593, E605, E6CB, E698 and E11D establish the
pointer tables, source graphics bank, layout dimensions, and horizontal pitch.
This exports static base configurations. Neighbor/state-dependent replacements,
attribute palettes, and collision anchors are not reconstructed here.
"""

import argparse
import json
from pathlib import Path

from extract_chr import PALETTE, decode_tile, load_rom, parse_header, sha256


TYPES = {0: "empty", 1: "floor", 3: "pillar", 4: "gate", 20: "wall"}
THEMES = [
    ("dungeon", "RAM $04BB == 0", 0x8E26, 0xB0E9),
    ("palace", "RAM $04BB != 0", 0x8DEA, 0xB043),
]
EVIDENCE_FILES = [
    "graphics-function-e0c4.json", "graphics-function-e593.json",
    "graphics-function-e67f.json", "graphics-function-e723.json",
    "graphics-function-e11d.json",
]


def file_offset(bank, address):
    if 0xC000 <= address <= 0xFFFF:
        return 16 + 7 * 16384 + address - 0xC000
    if not 0x8000 <= address < 0xC000:
        raise ValueError(f"Not a mapped PRG address: {address:#x}")
    return 16 + bank * 16384 + address - 0x8000


def export_fidelity_v2(rom, member, output, analysis_output):
    """Export every real theme-table entry; retain unavailable slots explicitly."""
    def word(bank, cpu):
        p = file_offset(bank, cpu)
        return int.from_bytes(rom[p:p + 2], "little")

    decoded = [decode_tile(rom[0xC010 + t * 16:0xC010 + (t + 1) * 16]) for t in range(1024)]

    def definition(kind, ident, layout, graphics, conditions=None):
        item = {"type": kind, "id": ident, "width": 56, "height": 80,
                "origin_x": 0, "origin_y": 0, "advance_x": 32, "advance_y": 64,
                "layout_cpu_address": layout, "graphics_cpu_address": graphics,
                "conditions": conditions or {"selection": "base pointer table; dynamic context can replace this"}}
        try:
            lp, gp = file_offset(5, layout), file_offset(5, graphics)
            skip = rom[lp]
            if skip > 10:
                raise ValueError("layout header is outside original ten-row range")
            encoded = list(rom[lp + 1:lp + 1 + 7 * (10 - skip)])
            ids, raw_words = [], []
            for i in range(128):
                value = word(5, graphics + 2 * i)
                if value == 65535:
                    break
                raw_words.append(value)
                if value:
                    if value >= 1024:
                        raise ValueError("base pointer does not identify a bank3 tile-word list; original context replacement required")
                    ids.append(value)
            else:
                raise ValueError("no word-list terminator within original eight-bit index range")
            grid = [0] * (skip * 7) + encoded
            pixels, writes, known = bytearray(4480), bytearray(4480), bytearray([1] * 4480)
            missing = sorted({index for index in grid if index > len(ids)})
            source_grid = []
            for cell, index in enumerate(grid):
                source_id = ids[index - 1] if 0 < index <= len(ids) else None
                source_grid.append(source_id)
                if not index:
                    continue
                x0, y0 = cell % 7 * 8, cell // 7 * 8
                for y in range(8):
                    p = (y0 + y) * 56 + x0
                    writes[p:p + 8] = b"\1" * 8
                    if source_id is None:
                        known[p:p + 8] = b"\0" * 8
                    else:
                        pixels[p:p + 8] = bytes(decoded[source_id][y * 8:y * 8 + 8])
            item.update({"status": "partial_context_required" if missing else "decoded_base_definition",
                         "skip_rows": skip, "content_y_offset": skip * 8,
                         "layout_file_offset": lp, "layout_size_bytes": len(encoded) + 1,
                         "layout_sha256": sha256(rom[lp:lp + len(encoded) + 1]),
                         "graphics_file_offset": gp, "graphics_words_raw": raw_words,
                         "graphics_words_sha256": sha256(rom[gp:gp + 2 * (len(raw_words) + 1)]),
                         "source_graphics_tile_ids": ids,
                         "source_graphics_file_offsets": [0xC010 + i * 16 for i in ids],
                         "layout_grid": grid, "source_tile_grid": source_grid,
                         "unresolved_layout_indices": missing,
                         "pixels": list(pixels), "write_mask": list(writes), "pixel_known_mask": list(known),
                         "pixel_sha256": sha256(pixels), "write_mask_sha256": sha256(writes)})
        except (ValueError, IndexError) as error:
            item.update({"status": "context_required", "reason": str(error), "pixels": [], "write_mask": []})
        return item

    evidence = []
    for p in sorted(Path("analysis/rea").glob("background-v2-*function-*.json")):
        if p.stat().st_size:
            record = json.loads(p.read_text())
            if "evidence_id" in record:
                evidence.append({"file": str(p), "evidence_id": record["evidence_id"]})
    for name in EVIDENCE_FILES:
        p = Path("analysis/rea") / name
        record = json.loads(p.read_text())
        evidence.append({"file": str(p), "evidence_id": record["evidence_id"]})
    origins = []
    table_offset = file_offset(7, 0xEBB2)
    for position in range(30):
        address = word(7, 0xEBB2 + 2 * position)
        page = (address - 0x2000) // 1024
        origins.append({"position": position, "row": position // 10, "column": position % 10,
                        "ppu_address": address, "world_x": page * 256 + address % 32 * 8,
                        "world_y": (address % 1024) // 32 * 8})
    result = {
        "schema_version": 2, "pixel_format": "row-major uint8 indices0..3",
        "palette_verified": False,
        "source_rom": {"member": member, "sha256": sha256(rom)},
        "status": "All32 type slots represented per theme; original table entries and code-proven variants decoded without substitute graphics",
        "native_layout": {"columns": 7, "rows": 10, "width": 56, "height": 80,
                          "advance_x": 32, "advance_y": 64, "room_columns": 10, "room_rows": 3,
                          "room_origin_x": 16, "room_origin_y": 0, "main_room_extent_x": [16, 360],
                          "main_room_extent_y": [0, 208], "logical_room_extent_x": [16, 336], "viewport_width": 256,
                          "camera": {"scroll_min": 8, "scroll_max": 80, "easing_step": 4,
                                     "desired_scroll": "clamp((player_x_low &252)-120,8,80); player_x_high!=0 forces80",
                                     "source": "bank5:87E9..884E, separately traced by actor agent", "rea_file": "analysis/rea/actor-camera-8830.json"},
                          "hud": {"glyph_width": 8, "glyph_height": 8, "y": 216, "background_palette_slot": 3,
                                  "player": {"x": 16, "ppu_address": 0x2362, "advance_x": 8,
                                             "filled_chr_tile": 0xFD, "empty_chr_tile": 0xFE},
                                  "opponent": {"x": 240, "ppu_address": 0x237E, "advance_x": -8,
                                               "filled_chr_tile": 0xFB, "empty_chr_tile": 0},
                                  "glyph_pixels": None, "glyph_status": "Original CHR source for health glyphs not recovered; no guessed glyph pixels exported",
                                  "coordinate_evidence": ["analysis/rea/background-v2-function-8296.json", "analysis/rea/background-v2-function-82c3.json"],
                                  "output_height": 240, "optional_crop": {"top": 8, "bottom": 8, "status": "display profile choice; not claimed as original ROM behavior"}},
                          "origin_table_cpu_address": 0xEBB2, "origin_table_file_offset": table_offset,
                          "origin_table_sha256": sha256(rom[table_offset:table_offset + 60]),
                          "cell_origins": origins,
                          "draw_order": [row * 10 + column for row in (2, 1, 0) for column in range(10)],
                          "draw_passes": [
                              {"order": 0, "routine": "DED0", "purpose": "left-neighbor edge; context details retained as unresolved"},
                              {"order": 1, "routine": "DDCA", "purpose": "bottom-neighbor first row", "origin_y": 192, "clip": "first2 PPU tile rows because RAM$5E is set"},
                              {"order": 2, "routine": "DC24:E11A", "purpose": "currentroom bottom row", "positions": list(range(20, 30)), "origin_y": 128},
                              {"order": 3, "routine": "DC24:E11A", "purpose": "currentroom middle row", "positions": list(range(10, 20)), "origin_y": 64},
                              {"order": 4, "routine": "DC24:E11A", "purpose": "currentroom top row", "positions": list(range(10)), "origin_y": 0},
                              {"order": 5, "routine": "DDE9", "purpose": "above-neighbor bottom row", "origin_y": -64, "clip": "PPU address clipping suppresses writes outside visible nametable rows"}],
                          "zero_pixel_rule": "Draw index0 when write_mask is1; zero layout index means no nametable write",
                          "unresolved_pixel_rule": "When pixel_known_mask is0, no source pixel has been established; do not substitute art"},
        "themes": [], "rea_evidence": evidence,
        "limitations": [
            "Original tables contain23 dungeon layout entries and30 palace entries; unused type slots are explicit unavailable records, not invented definitions.",
            "Some original base pairs reference indices beyond their standalone graphics list; these remain partial pending complete CHR allocation/context recovery.",
            "Original theme palettes/attributes are recovered separately and are not replaced with guessed colors here.",
            "Context variants are exact source combinations selected by observed code. The full original condition tree and room-global CHR allocation are not executed by this extractor.",
            "Native scroll8..80 with4-pixel easing was recovered separately by actor tracing; PPU origins and draw order are observed, not inferred from screenshots.",
            "Health HUD coordinates, tile IDs, and palette slot are proven, but original glyph pixels remain unrecovered. No substitute glyph data is exported."]}
    for theme_id, selector, layout_table, graphics_table in THEMES:
        count = 23 if theme_id == "dungeon" else 30
        theme = {"id": theme_id, "selector": selector, "original_table_entry_count": count,
                 "layout_pointer_table": {"bank": 4, "cpu_address": layout_table, "file_offset": file_offset(4, layout_table)},
                 "graphics_pointer_table": {"bank": 2, "cpu_address": graphics_table, "file_offset": file_offset(2, graphics_table)},
                 "tiles": [], "variants": [], "overlays": [], "shadowed_overlay_records": []}
        for kind in range(32):
            if kind >= count:
                item = {"type": kind, "id": f"type_{kind:02d}", "status": "not_defined_in_original_theme_table",
                        "pixels": [], "write_mask": [], "reason": "Pointer table ends before this index; no substitute graphic created"}
            else:
                item = definition(kind, f"type_{kind:02d}", word(4, layout_table + 2 * kind), word(2, graphics_table + 2 * kind))
            item["label"] = TYPES.get(kind, f"native_type_{kind:02d}")
            theme["tiles"].append(item)
        palace = theme_id == "palace"
        specs = [
            (20, "wall_repeated", 0x90F7 if palace else 0x91E6, 0xBCB1 if palace else 0xB96F,
             {"routine": "E11D:E2DE..E2F1/EA13", "condition": "type20; increment RAM$06F8; use repeated layout when(counter&3)!=1"}),
            (0, "empty_modifier3_overlay", 0x95A2 if palace else 0x8B41, 0xBE6B if palace else 0xB94F,
             {"routine": "E11D:E33A..E377", "condition": "rawtile upperbits$60; current lowtype0; normal currentroom pass; draw after base"}),
            (12, "clipped_type12", 0x8F3A, 0xBD3D,
             {"routine": "E11D:E29C..E2B7", "condition": "clipped/neighbor pass selects type12 replacement; full branch details retained in Rea evidence"}),
            (12, "left_neighbor_26_to29", 0x91B0, 0xB8E9,
             {"routine": "E11D:E22F..E26C", "condition": "leftneighbor type26..29 and currenttype12; normal pass; palette$59 uses neighbor position19"}),
            (13, "mirror_inactive_background", 0x8D9D if palace else 0x8D22, 0xBBDB if palace else 0xB96F,
             {"routine": "E11D:E213..E21B; E554:E55A..E58D", "condition": "currenttype13 and RAM$04FC==0; render native floor background; mirror foreground remains separate"}),
        ]
        if not palace:
            specs.append((1, "modifier1_floor_overlay", 0x9528, 0xB96F,
                          {"routine": "EA32", "condition": "upperbits$20 and normal floor/sharedgfx types0,1,10,11,22; draw after base; other types require their selected graphics list"}))
        for kind, ident, layout, graphics, conditions in specs:
            item = definition(kind, ident, layout, graphics, conditions)
            rules = {
                "wall_repeated": {"current_type": 20, "wall_counter_increment_before_test": True, "wall_counter_modulus": 4, "wall_counter_remainder_not": 1, "wall_counter_initial_value_verified": False, "operation": "replace_base"},
                "empty_modifier3_overlay": {"current_type": 0, "raw_mask": 224, "raw_value": 96, "pass": "current_room", "operation": "draw_after_base"},
                "clipped_type12": {"current_type": 12, "pass": "above_neighbor", "operation": "replace_base"},
                "left_neighbor_26_to29": {"current_type": 12, "left_type_in": [26, 27, 28, 29], "pass": "current_room", "operation": "replace_base"},
                "mirror_inactive_background": {"current_type": 13, "ram_equals": {"0x04fc": 0}, "operation": "replace_base_background_only"},
                "modifier1_floor_overlay": {"current_type_in": [0, 1, 10, 11, 22], "raw_mask": 224, "raw_value": 32, "pass": "current_room", "requires_original_graphics_selector": True, "operation": "draw_after_base"},
            }
            item["selector_rule"] = rules[ident]
            theme["variants"].append(item)
        # Original E860 joins use distinct tables for the two sides. Every
        # record is [matched_type, gfx_selector, grid_low, grid_high].
        for side, pointer_bank, pointer_table in [
            ("left_front", 4, 0xB899 if palace else 0xB86B),
            ("right_front", 2, 0xB0AD if palace else 0xB07F),
        ]:
            for table_type in range(count):
                records_cpu = word(pointer_bank, pointer_table + 2 * table_type)
                seen_matches = set()
                for record_index in range(64):
                    record_cpu = records_cpu + 4 * record_index
                    rp = file_offset(6, record_cpu)
                    matched = rom[rp]
                    if matched == 255:
                        break
                    if matched in seen_matches:
                        theme["shadowed_overlay_records"].append({"side": side, "table_type": table_type,
                                                                   "matched_type": matched, "record_cpu_address": record_cpu,
                                                                   "record_file_offset": rp, "record_bytes_hex": rom[rp:rp + 4].hex(" "),
                                                                   "reason": "Original selector returns on first match; this duplicate is unreachable"})
                        continue
                    seen_matches.add(matched)
                    gfx_selector = rom[rp + 1]
                    grid_cpu = int.from_bytes(rom[rp + 2:rp + 4], "little")
                    gp = file_offset(6, grid_cpu)
                    graphics_cpu = 0xBFD9 if gfx_selector == 0xD2 else word(2, 0xB53F + ((2 * gfx_selector) & 255))
                    gfxp = file_offset(5, graphics_cpu)
                    words = []
                    for n in range(128):
                        value = word(5, graphics_cpu + 2 * n)
                        if value == 65535:
                            break
                        if value:
                            words.append(value)
                    grid = list(rom[gp:gp + 6])
                    pixels, writes, known = bytearray(384), bytearray(384), bytearray([1] * 384)
                    unresolved = set()
                    source_grid = []
                    for cell, index in enumerate(grid):
                        source_id = words[index - 1] if 0 < index <= len(words) and words[index - 1] < 1024 else None
                        source_grid.append(source_id)
                        if not index:
                            continue
                        if source_id is None:
                            unresolved.add(index)
                        x0, y0 = cell % 3 * 8, cell // 3 * 8
                        for y in range(8):
                            dest = (y0 + y) * 24 + x0
                            writes[dest:dest + 8] = b"\1" * 8
                            if source_id is None:
                                known[dest:dest + 8] = b"\0" * 8
                            else:
                                pixels[dest:dest + 8] = bytes(decoded[source_id][8 * y:8 * y + 8])
                    current = matched if side == "left_front" else table_type
                    selector_rule = {"pass": "current_room", "current_type": current, "operation": "draw_after_base_and_modifiers"}
                    if side == "left_front":
                        selector_rule["left_type"] = table_type
                    else:
                        selector_rule.update({"below_type": matched, "right_type_in": [0, 11, 12]})
                    theme["overlays"].append({
                        "id": f"{side}_{table_type:02d}_{matched:02d}", "side": side,
                        "status": "partial_context_required" if unresolved else "decoded_context_overlay",
                        "type": current, "width": 24, "height": 16,
                        "origin_x": 0 if side == "left_front" else 32, "origin_y": 64,
                        "selector_rule": selector_rule, "pixels": list(pixels),
                        "write_mask": list(writes), "pixel_known_mask": list(known),
                        "pixel_sha256": sha256(pixels), "write_mask_sha256": sha256(writes),
                        "layout_grid": grid, "source_tile_grid": source_grid,
                        "unresolved_layout_indices": sorted(unresolved),
                        "pointer_table_bank": pointer_bank, "pointer_table_cpu": pointer_table,
                        "pointer_table_type": table_type, "record_cpu_address": record_cpu,
                        "record_index": record_index,
                        "record_file_offset": rp, "record_bytes_hex": rom[rp:rp + 4].hex(" "),
                        "graphics_selector": gfx_selector, "graphics_cpu_address": graphics_cpu,
                        "graphics_file_offset": gfxp, "source_graphics_tile_ids": words,
                        "source_graphics_file_offsets": [0xC010 + t * 16 for t in words if t < 1024],
                        "grid_cpu_address": grid_cpu, "grid_file_offset": gp,
                    })
                else:
                    raise ValueError("Context record list does not terminate within original index range")
        result["themes"].append(theme)
    # Validate every established pixel against the original ROM bitplanes,
    # independently of the decoder used above. Unknown cells remain explicit.
    validation = {"definitions_checked": 0, "known_pixels_checked": 0,
                  "source_written_pixels_checked": 0, "explicit_unknown_pixels": 0}
    for theme in result["themes"]:
        for item in theme["tiles"] + theme["variants"] + theme["overlays"]:
            if not item.get("pixels"):
                continue
            width, height = item["width"], item["height"]
            assert len(item["pixels"]) == len(item["write_mask"]) == len(item["pixel_known_mask"]) == width * height
            assert sha256(bytes(item["pixels"])) == item["pixel_sha256"]
            assert sha256(bytes(item["write_mask"])) == item["write_mask_sha256"]
            columns = width // 8
            for cell, (index, tile_id) in enumerate(zip(item["layout_grid"], item["source_tile_grid"])):
                for y in range(8):
                    for x in range(8):
                        destination = (cell // columns * 8 + y) * width + cell % columns * 8 + x
                        assert item["write_mask"][destination] == bool(index)
                        if index and tile_id is None:
                            assert not item["pixel_known_mask"][destination]
                            validation["explicit_unknown_pixels"] += 1
                            continue
                        assert item["pixel_known_mask"][destination]
                        expected = 0
                        if tile_id is not None:
                            source = 0xC010 + tile_id * 16
                            expected = ((rom[source + y] >> (7 - x)) & 1) + 2 * ((rom[source + y + 8] >> (7 - x)) & 1)
                            validation["source_written_pixels_checked"] += 1
                        assert item["pixels"][destination] == expected
                        validation["known_pixels_checked"] += 1
            validation["definitions_checked"] += 1
    result["validation"] = validation
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, separators=(",", ":")) + "\n")
    analysis_output.mkdir(parents=True, exist_ok=True)
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        previews = []
    else:
        previews = []
        for theme in result["themes"]:
            items = theme["tiles"] + theme["variants"]
            rows = (len(items) + 7) // 8
            preview = Image.new("L", (1024, 44 + rows * 188), 24)
            draw = ImageDraw.Draw(preview)
            draw.text((5, 3), f"ORIGINAL {theme['id'].upper()} DEFINITIONS AND CONTEXT VARIANTS; DIAGNOSTIC GRAYSCALE", fill=255)
            draw.text((5, 19), "UNRESOLVED SLOTS LABELED; NO SUBSTITUTE GRAPHICS; ORIGINAL COLORS EXPORTED SEPARATELY", fill=255)
            for i, item in enumerate(items):
                x, y = i % 8 * 128, 44 + i // 8 * 188
                if item.get("pixels"):
                    pixels = bytes(PALETTE[p] for p in item["pixels"])
                    image = Image.frombytes("L", (56, 80), pixels).resize((112, 160), Image.Resampling.NEAREST)
                    preview.paste(image, (x, y))
                draw.text((x, y + 160), item["id"], fill=255)
                if item["status"] != "decoded_base_definition":
                    draw.text((x, y + 173), "PARTIAL" if item.get("pixels") else "UNAVAILABLE", fill=255)
            name = f"native-metatiles-v2-{theme['id']}-diagnostic.png"
            preview.save(analysis_output / name)
            previews.append(name)
    summary = {"asset": str(output), "sha256": sha256(output.read_bytes()), "schema_version": 2,
               "counts": {theme["id"]: {"type_slots": len(theme["tiles"]),
                          "decoded": sum(i["status"] == "decoded_base_definition" for i in theme["tiles"]),
                          "partial": sum(i["status"] == "partial_context_required" for i in theme["tiles"]),
                          "context_required": sum(i["status"] == "context_required" for i in theme["tiles"]),
                          "unavailable": sum(i["status"] == "not_defined_in_original_theme_table" for i in theme["tiles"]),
                          "context_variants": len(theme["variants"]),
                          "context_overlays": len(theme["overlays"]),
                          "decoded_overlays": sum(i["status"] == "decoded_context_overlay" for i in theme["overlays"])} for theme in result["themes"]},
               "native_geometry": result["native_layout"], "previews": previews,
               "rea_evidence": evidence, "validation": validation, "limitations": result["limitations"]}
    (analysis_output / "graphics-fidelity-findings.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary["counts"]))
    print(output)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--output", type=Path, default=Path("web/assets/native-metatiles.json"))
    parser.add_argument("--analysis-output", type=Path, default=Path("analysis/graphics"))
    parser.add_argument("--fidelity-v2", action="store_true", help="Export all native table slots, variants, and room geometry to analysis artifacts")
    args = parser.parse_args()
    rom, member = load_rom(args.input)
    h = parse_header(rom)
    if (h["mapper"], h["prg_rom_size_bytes"], h["trainer_size_bytes"]) != (2, 131072, 0):
        raise ValueError("This ROM-specific extractor expects mapper2, eight16-KiB PRG banks and no trainer")
    if args.fidelity_v2:
        output = args.output
        if output == Path("web/assets/native-metatiles.json"):
            output = args.analysis_output / "native-metatiles-v2.json"
        export_fidelity_v2(rom, member or args.input.name, output, args.analysis_output)
        return

    def word(bank, address):
        offset = file_offset(bank, address)
        return int.from_bytes(rom[offset:offset + 2], "little")

    evidence = []
    for name in EVIDENCE_FILES:
        path = Path("analysis/rea") / name
        if path.exists():
            item = json.loads(path.read_text())
            evidence.append({"file": str(path), "evidence_id": item["evidence_id"]})
    # B80E in selected PRG bank2 initializes PPU destination $1010 while the
    # allocation counter $76 starts at0. Thus layout index1 addresses word0.
    initializer_offset = 0xB81E
    expected_initializer = bytes.fromhex("a9 10 85 72 85 73 a9 00 85 75 8d 9a 04 85 76")
    if rom[initializer_offset:initializer_offset + len(expected_initializer)] != expected_initializer:
        raise ValueError("Original CHR allocation initialization anchor does not match")
    result = {
        "schema_version": 1,
        "pixel_format": "row-major uint8 indices 0..3",
        "palette_verified": False,
        "status": "Original base compositions decoded from code-traced tables; context-dependent selection and palettes unresolved",
        "source_rom": {"member": member or args.input.name, "sha256": sha256(rom)},
        "native_layout": {"columns": 7, "rows": 10, "tile_width": 8, "tile_height": 8,
                          "advance_x": 32, "advance_x_evidence": "E11D:E4EA..E4F3 advances nametable address by4 columns",
                          "origin_status": "origin0,0 is E6CB call destination before header row skips; collision/world anchor not traced",
                          "zero_layout_index": "leave existing nametable tile unchanged",
                          "nonzero_layout_index": "1-based index into compact nonzero graphics-word list",
                          "source_graphics": "PRG bank3, 16-byte native2bpp tiles"},
        "allocation_initializer": {"rom_file_offset": initializer_offset,
                                   "bytes_hex": expected_initializer.hex(" "),
                                   "method": "raw byte anchor plus manual6502 decoding",
                                   "observation": "LDA#$10; STA$72; STA$73; LDA#0; STA$75; STA$049A; STA$76. PPU destination$1010 and allocation counter0 prove layout index1 uses first loaded word."},
        "rea_evidence": evidence,
        "themes": [],
        "limitations": [
            "Theme names are inferred visually; the original code selects the two tables using RAM$04BB.",
            "Exports are original static base layouts for types0,1,3,4,20. Original neighbor/state code can replace the graphics list or layout.",
            "Original palette/attribute bytes are not decoded; pixel indices are preserved exactly.",
            "write_mask identifies source nametable writes, including pixels with index0. Index0 is not universally transparent background art.",
            "No original vertical collision origin or row advance is claimed; renderer may scale these compositions as an explicit reconstruction choice.",
        ],
    }
    decoded_tiles = [decode_tile(rom[0xC010 + t * 16:0xC010 + (t + 1) * 16]) for t in range(1024)]
    for theme_id, selector, layout_table, graphics_table in THEMES:
        theme = {"id": theme_id, "selector": selector, "name_status": "visual inference",
                 "layout_pointer_table": {"prg_bank": 4, "cpu_address": layout_table,
                                          "rom_file_offset": file_offset(4, layout_table)},
                 "graphics_pointer_table": {"prg_bank": 2, "cpu_address": graphics_table,
                                            "rom_file_offset": file_offset(2, graphics_table)},
                 "tiles": []}
        for kind, label in TYPES.items():
            layout_cpu = word(4, layout_table + 2 * kind)
            graphics_cpu = word(2, graphics_table + 2 * kind)
            layout_start, graphics_start = file_offset(5, layout_cpu), file_offset(5, graphics_cpu)
            skip = rom[layout_start]
            if not 0 <= skip <= 10:
                raise ValueError(f"Invalid skipped-row count for {theme_id}:{kind}")
            encoded_layout = list(rom[layout_start + 1:layout_start + 1 + 7 * (10 - skip)])
            words, compact_ids = [], []
            for index in range(128):
                tile_id = word(5, graphics_cpu + 2 * index)
                if tile_id == 0xFFFF:
                    break
                words.append(tile_id)
                if tile_id:
                    if tile_id >= 1024:
                        raise ValueError(f"Source bank3 tile outside range: {tile_id:#x}")
                    compact_ids.append(tile_id)
            else:
                raise ValueError("Graphics list missingFFFF terminator within8-bit index range")
            if max(encoded_layout, default=0) > len(compact_ids):
                raise ValueError("Layout references graphics outside its base word list")
            grid = [0] * (skip * 7) + encoded_layout
            pixels, mask = bytearray(56 * 80), bytearray(56 * 80)
            for cell, index in enumerate(grid):
                if not index:
                    continue
                tile = decoded_tiles[compact_ids[index - 1]]
                x0, y0 = cell % 7 * 8, cell // 7 * 8
                for y in range(8):
                    dest = (y0 + y) * 56 + x0
                    pixels[dest:dest + 8] = bytes(tile[y * 8:y * 8 + 8])
                    mask[dest:dest + 8] = b"\1" * 8
            theme["tiles"].append({
                "type": kind, "id": f"type_{kind:02d}", "label": label,
                "width": 56, "height": 80, "origin_x": 0, "origin_y": 0, "advance_x": 32,
                "skip_rows": skip, "content_y_offset": skip * 8,
                "pixels": list(pixels), "write_mask": list(mask),
                "pixel_sha256": sha256(pixels), "write_mask_sha256": sha256(mask),
                "layout_grid": grid,
                "source_graphics_tile_ids": compact_ids,
                "source_graphics_file_offsets": [0xC010 + t * 16 for t in compact_ids],
                "layout_cpu_address": layout_cpu, "layout_file_offset": layout_start,
                "layout_size_bytes": len(encoded_layout) + 1,
                "layout_sha256": sha256(rom[layout_start:layout_start + len(encoded_layout) + 1]),
                "graphics_cpu_address": graphics_cpu, "graphics_file_offset": graphics_start,
                "graphics_words_raw": words, "graphics_word_count": len(words),
                "graphics_words_sha256": sha256(rom[graphics_start:graphics_start + 2 * (len(words) + 1)]),
                "status": "static base composition recovered from original pointer tables and loader; dynamic context not executed",
            })
        result["themes"].append(theme)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, separators=(",", ":")) + "\n")
    args.analysis_output.mkdir(parents=True, exist_ok=True)
    try:
        from PIL import Image, ImageDraw
        from PIL.PngImagePlugin import PngInfo
    except ImportError:
        preview_name = None
    else:
        preview = Image.new("L", (800, 450), 24)
        draw = ImageDraw.Draw(preview)
        draw.text((5, 3), "ORIGINAL BASE LAYOUTS FROM CODE-TRACED POINTER TABLES; DIAGNOSTIC GRAYSCALE", fill=255)
        draw.text((5, 19), "PALETTES/CONTEXT VARIANTS UNRESOLVED; SOURCE WRITE MASK PRESERVED IN JSON", fill=255)
        for row, theme in enumerate(result["themes"]):
            for col, tile in enumerate(theme["tiles"]):
                image = Image.frombytes("L", (56, 80), bytes(PALETTE[p] for p in tile["pixels"]))
                image = image.resize((112, 160), Image.Resampling.NEAREST)
                x, y = col * 160, 70 + row * 188
                preview.paste(image, (x, y))
                draw.text((x, y - 22), f"{theme['id']} type{tile['type']:02d}", fill=255)
                draw.text((x, y + 162), tile["label"], fill=255)
        info = PngInfo()
        info.add_text("Description", result["status"] + "; diagnostic grayscale, not original palettes")
        preview_name = "native_metatiles_diagnostic_grayscale.png"
        preview.save(args.analysis_output / preview_name, pnginfo=info)
    metadata = {"file": str(args.output), "sha256": sha256(args.output.read_bytes()),
                "theme_count": len(result["themes"]), "composition_count": sum(len(t["tiles"]) for t in result["themes"]),
                "preview_png": preview_name, "rea_evidence": evidence,
                "limitations": result["limitations"]}
    (args.analysis_output / "native_metatiles.json").write_text(json.dumps(metadata, indent=2) + "\n")
    print(f"Exported10 original base compositions in2 table variants to {args.output}")


if __name__ == "__main__":
    main()
