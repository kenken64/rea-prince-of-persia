#!/usr/bin/env python3
"""Recover original NES actor metasprites and indexed pixels from this ROM.

Unlike the earlier visual candidates, this follows the bank4 frame pointer
tables, 8-byte OAM part records, tile-placement grids, bank5 graphics upload
wordlists, and fixed sprite CHR upload. No tiles or pixels are painted.
"""
import argparse
import json
from collections import Counter
from pathlib import Path

from extract_chr import decode_tile, load_rom, parse_header, sha256

ROM_SHA256 = "5f14d4d31cc588ddcdfb2b4d46eb7051b06d02655c9208037ef7ae137c4740e4"


class ExtractionError(ValueError):
    pass


def offset8(value):
    """B419 uses one's-complement negative offsets, not signed two's complement."""
    return value if value < 0x7F else value - 255


def signed8(value):
    return value if value < 128 else value - 256


class Actors:
    def __init__(self, rom):
        self.rom = rom
        self.start = parse_header(rom)["prg_rom_file_offset"]
        self.banks = [rom[self.start + i * 16384:self.start + (i + 1) * 16384] for i in range(8)]
        self.shared = self.shared_chr()

    def bytes(self, bank, cpu, count):
        if not 0x8000 <= cpu or cpu + count > 0xC000:
            raise ExtractionError(f"bank{bank} CPU{cpu:04X}: invalid read of{count} bytes")
        return self.banks[bank][cpu - 0x8000:cpu - 0x8000 + count]

    def word(self, bank, cpu):
        return int.from_bytes(self.bytes(bank, cpu, 2), "little")

    def file_offset(self, bank, cpu):
        return self.start + bank * 16384 + cpu - 0x8000

    def tile(self, word, bank_base=0):
        bank = bank_base + (word >> 10)
        index = word & 1023
        if bank >= len(self.banks):
            raise ExtractionError(f"tile word{word:04X}, bank base{bank_base}: bank out of bounds")
        source = self.start + bank * 16384 + index * 16
        return {"word": word, "source_bank": bank, "source_tile": index,
                "source_file_offset": source, "pixels": decode_tile(self.rom[source:source + 16])}

    def wordlist(self, role, graphics_id):
        table = 0xA42F if role == "prince" else 0x9D93
        pointer = self.word(5, table + graphics_id * 2)
        words = []
        for i in range(128):
            word = self.word(5, pointer + 2 * i)
            if word == 0xFFFF:
                return pointer, words
            # Normal actor upload has06C2=0: zero words consume no CHR slot.
            if word:
                words.append(self.tile(word))
        raise ExtractionError(f"unterminated graphics wordlist at{pointer:04X}")

    def shared_chr(self):
        """D40B/89F5/F32B upload at$0400 from bank3 using alternate list0.

        FFFF separates chunks; a second consecutive terminator ends the stream.
        The first six chunks copy zero words; 89F5 then clears06C2 and later
        zero words leave the CHR destination unchanged. This matters for swords.
        """
        pointer = self.word(5, 0x9D93)
        mapping = {}
        chunk = 0
        previous_end = False
        slot = 0x40
        for i in range(1024):
            word = self.word(5, pointer + i * 2)
            if word == 0xFFFF:
                if previous_end:
                    return mapping
                previous_end = True
                chunk += 1
            else:
                previous_end = False
                if word or chunk < 6:
                    mapping[slot] = self.tile(word, 3)
                    slot += 1
        raise ExtractionError("unterminated shared sprite CHR stream")

    def frame(self, role, frame_index):
        if role == "prince":
            lo, hi, index = 0x8008, 0x810F, frame_index
        elif role == "guard":
            lo, hi, index = 0x8216, 0x825D, frame_index - 0x97
        else:
            lo, hi, index = 0x82B0, 0x82D4, frame_index - 150
        pointer = self.bytes(4, lo + index, 1)[0] | self.bytes(4, hi + index, 1)[0] << 8
        parts, unresolved = [], []
        for part_index in range(12):
            at = pointer + part_index * 8
            if self.bytes(4, at, 1)[0] == 0xFF:
                break
            raw = list(self.bytes(4, at, 8))
            graphics_id, x, y, width, height, attr, grid_lo, grid_hi = raw
            if not (0 < width <= 16 and 0 < height <= 12):
                raise ExtractionError(f"frame record{at:04X} has invalid dimensions{width}x{height}")
            grid_pointer = grid_lo | grid_hi << 8
            grid = list(self.bytes(4, grid_pointer, width * height))
            part = {"record_cpu_address": at, "record_file_offset": self.file_offset(4, at),
                    "record_bytes": raw, "graphics_id": graphics_id,
                    "origin_x": offset8(x), "origin_y": signed8(y) - height * 8 + 3,
                    "width_tiles": width, "height_tiles": height, "oam_attribute": attr,
                    "palette_group": attr & 3, "tile_grid_cpu_address": grid_pointer,
                    "tile_grid_file_offset": self.file_offset(4, grid_pointer), "tile_grid": grid,
                    "sprites": []}
            if part_index == 0 and role != "object":
                list_pointer, uploaded = self.wordlist(role, graphics_id)
                part["graphics_wordlist_cpu_address"] = list_pointer
                part["graphics_wordlist_file_offset"] = self.file_offset(5, list_pointer)
                part["graphics_words"] = [tile["word"] for tile in uploaded]
            for cell, tile_id in enumerate(grid):
                if not tile_id:
                    continue
                if role == "object" and part_index == 0:
                    tile = self.shared.get((0x40 + tile_id) & 255)
                elif part_index == 0:
                    tile = uploaded[tile_id - 1] if tile_id <= len(uploaded) else None
                else:
                    tile = self.shared.get((0x83 + graphics_id + tile_id) & 255)
                if tile is None:
                    unresolved.append({"part": part_index, "cell": cell, "tile_id": tile_id,
                                       "reason": "CHR slot is not defined by the traced upload"})
                    continue
                sprite = {"x": part["origin_x"] + (cell % width) * 8,
                          "y": part["origin_y"] + (cell // width) * 8,
                          "palette_group": attr & 3, "oam_attribute": attr,
                          "source_word": tile["word"], "source_bank": tile["source_bank"],
                          "source_tile": tile["source_tile"], "source_file_offset": tile["source_file_offset"],
                          "pixels": list(tile["pixels"])}
                part["sprites"].append(sprite)
            parts.append(part)
        else:
            raise ExtractionError("frame has no FF terminator within12 parts")
        if not parts:
            raise ExtractionError("empty frame")
        left = min(part["origin_x"] for part in parts)
        top = min(part["origin_y"] for part in parts)
        right = max(part["origin_x"] + part["width_tiles"] * 8 for part in parts)
        bottom = max(part["origin_y"] + part["height_tiles"] * 8 for part in parts)
        width, height = right - left, bottom - top
        pixels, palettes = [0] * (width * height), [0] * (width * height)
        # Earlier OAM entries have priority. Preserve that ordering where parts
        # overlap, and apply each hardware sprite's own flip flags.
        for part in parts:
            for sprite in part["sprites"]:
                for yy in range(8):
                    for xx in range(8):
                        sx = 7 - xx if sprite["oam_attribute"] & 0x40 else xx
                        sy = 7 - yy if sprite["oam_attribute"] & 0x80 else yy
                        pixel = sprite["pixels"][sy * 8 + sx]
                        dst = (sprite["y"] - top + yy) * width + sprite["x"] - left + xx
                        if pixel and not pixels[dst]:
                            pixels[dst] = pixel
                            palettes[dst] = sprite["palette_group"]
        return {"id": f"{role}_{frame_index:03d}", "actor": role,
                "frame_index": frame_index, "frame_cpu_address": pointer,
                "frame_file_offset": self.file_offset(4, pointer),
                "width": width, "height": height, "origin_x": left, "origin_y": top,
                "anchor_x": -left, "anchor_y": -top,
                "status": "recovered" if not unresolved else "incomplete",
                "pixels": pixels, "palette_groups": palettes, "parts": parts,
                "mirrored_origin_x": 8 - left - width,
                "unresolved": unresolved, "pixel_sha256": sha256(bytes(pixels))}


def previews(frames, destination):
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        return
    # RGB is a diagnostic display conversion; original palette indices are
    # preserved independently in the JSON and supplied by the palette extractor.
    colors = {0: [(0, 0, 0)] * 4,
              1: [(0, 0, 0), (255, 171, 63), (184, 34, 34), (255, 255, 255)],
              2: [(0, 0, 0), (92, 0, 48), (255, 171, 63), (221, 124, 240)],
              3: [(0, 0, 0), (0, 30, 116), (76, 154, 236), (168, 204, 236)]}
    for role in ("prince", "guard", "object"):
        selected = [f for f in frames if f["actor"] == role]
        columns, cw, ch = 16, 96, 152
        sheet = Image.new("RGB", (columns * cw, ((len(selected) + columns - 1) // columns) * ch), (15, 15, 20))
        draw = ImageDraw.Draw(sheet)
        for i, frame in enumerate(selected):
            image = Image.new("RGBA", (frame["width"], frame["height"]))
            image.putdata([(*colors[group][pixel], 255 if pixel else 0)
                           for pixel, group in zip(frame["pixels"], frame["palette_groups"])])
            image = image.resize((frame["width"] * 2, frame["height"] * 2), Image.Resampling.NEAREST)
            x, y = (i % columns) * cw, (i // columns) * ch
            sheet.paste(image, (x + max(0, (cw - image.width) // 2), y + 12), image)
            draw.text((x + 4, y + ch - 22), f"{frame['frame_index']:03d} {frame['status']}", fill=(220, 220, 220))
        path = destination.with_name(destination.stem + f"-{role}.png")
        sheet.save(path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("--output", type=Path, default=Path("analysis/graphics/actor-frames.json"))
    parser.add_argument("--preview", type=Path, default=Path("analysis/rea/actor-frames-preview.png"))
    args = parser.parse_args()
    rom, member = load_rom(args.input)
    if sha256(rom) != ROM_SHA256:
        raise SystemExit("This extractor requires the investigated USA ROM SHA256; refusing another revision.")
    extraction = Actors(rom)
    frames, errors = [], []
    for role, indices in [("prince", range(1, 256)), ("guard", range(151, 184)),
                          ("object", list(range(150, 157)) + [161, 162, 163])]:
        for index in indices:
            try:
                frames.append(extraction.frame(role, index))
            except ExtractionError as error:
                errors.append({"actor": role, "frame_index": index, "reason": str(error)})
    result = {
        "schema_version": 2, "source_rom_sha256": sha256(rom), "source_member": member,
        "status": "Original indexed pixels composed from traced OAM records and upload wordlists",
        "pixel_format": "row-major uint8 indices0..3", "transparent_index": 0,
        "native_default_facing": "left", "palette_groups_format": "row-major NES sprite palette group0..3 per pixel",
        "mirroring": "For original OAM horizontal reflection, reverse canvas pixels inX and set originX=8-originX-width; each hardware tile reflects about its8pixel anchor.",
        "position": {"origin": "Offsets from original actor anchor in unflipped OAM coordinates",
                     "y": "signed8(record offset) -8*heightTiles +3 (OAMY=RAM22+2; hardware top=OAMY+1)",
                     "x": "one's-complement decoded record offset; B550 complements then B419positions",
                     "c_game_alignment": "Editable renderer alignment choice: actor anchor=(C centerX-10,C feetY-3); add origin; frame15 draws16x40at(Cx-8,Cy-40). Original actorX is not a center coordinate."},
        "camera": {"evidence": "analysis/rea/actor-camera-8830.json", "ram_scroll": 0x6F,
                   "function_cpu_address": 0x87E9, "function_bank": 5,
                   "minimum": 8, "maximum": 80, "step_pixels": 4,
                   "desired": "clamp((playerX &~3)-128+8,8,80), subject to actor state checks",
                   "actor_oam_position": "Bank4B449 subtracts scroll6F from16-bit actorX before applying frame-part offsets."},
        "original_spawn": {
            "evidence": ["analysis/rea/actor-spawn-d7df.json", "analysis/rea/actor-spawn-ae78.json"],
            "position_table_bank": 2, "position_table_cpu_address": 0xA5F5,
            "position_table_file_offset": extraction.file_offset(2, 0xA5F5),
            "position_triplets": [list(extraction.bytes(2, 0xA5F5 + 3 * i, 3)) for i in range(30)],
            "normal_start": "Bank4BA80 callsD7DF(A=$24,X=$40); bank2AE78 adds36to32*column and64to64*row.",
            "intro_exception": "Level1 overrides original actorX to2 and starts script$96AE; this sequence is not reconstructed by the C engine.",
            "other_script_exceptions": "Level7(index6) usesD7DF(A=$2E,X=$66) and script$994E; level13(index12) forces facing0 and first-entryX0. These original script states are not reconstructed."},
        "object_entities": {
            "classification": "Original entity descriptors, first animation bytes, fixed-CHR framing, and placement are recovered; bytecode frame timing remains approximate.",
            "anchor": "Object builderE825 uses tile-position tableA5F5 directly: anchorX=32*column,anchorY=64*row. Native room bitmap originX16 is already included by each object part's offsets.",
            "tile22_sword": {"template_bank": 2, "template_cpu_address": 0xAD10,
                             "template_bytes": list(extraction.bytes(2, 0xAD10, 16)),
                             "script_bank": 5, "script_cpu_address": 0x9C96,
                             "frames": [161, 162], "initial_frame": 161,
                             "mirrored": True, "initial_origin": [15, 63],
                             "source_frame_ids": ["object_161", "object_162"]},
            "tile10_potion": {"template_bank": 2, "template_cpu_address": 0xADA1,
                              "template_bytes": list(extraction.bytes(2, 0xADA1, 16)),
                              "script_bank": 5, "script_cpu_address": 0x9CB3,
                              "frames": [150], "initial_frame": 150,
                              "mirrored": False, "initial_origin": [32, 55],
                              "source_frame_ids": ["object_150"]},
            "tile10_potion_bit40": {"template_bank": 2, "template_cpu_address": 0xADB1,
                                    "template_bytes": list(extraction.bytes(2, 0xADB1, 16)),
                                    "script_bank": 5, "script_cpu_address": 0x9CB7,
                                    "frames": [163], "initial_frame": 163,
                                    "mirrored": False, "initial_origin": [32, 58],
                                    "source_frame_ids": ["object_163"]},
            "potion_bubbles": {"template_bank": 2, "template_cpu_address": 0xADC1,
                               "template_bytes": list(extraction.bytes(2, 0xADC1, 16)),
                               "script_bank": 5, "script_cpu_address": 0x9CD8,
                               "frames": list(range(151, 157)), "initial_frame": 151,
                               "mirrored": False, "initial_origin": [36, 51],
                               "source_frame_ids": [f"object_{i:03d}" for i in range(151, 157)]}},
        "evidence": ["analysis/rea/actor-pointer-b2c3.json", "analysis/rea/actor-grid-b3b7.json",
                     "analysis/rea/actor-position-b419.json", "analysis/rea/actor-oam-full-b49c.json",
                     "analysis/rea/actor-upload-8008.json", "analysis/rea/actor-shared-init-d40b.json",
                     "analysis/rea/graphics-function-f39e.json", "analysis/rea/graphics-function-89f5.json"],
        "pose_sequences": {
            "classification": "Reconstruction action mapping; frame identities/layout/pixels are recovered, action timing is not",
            "prince": {"stand": [15], "run": list(range(2, 15)), "jump": [39, 40, 41, 42, 43, 44],
                       "standing_jump": [16, 18, 19, 21, 22, 23, 24, 25, 26],
                       "fall": [102, 103, 104, 105, 106], "hang": [79],
                       "climb": list(range(135, 150)), "hurt": [172, 173, 174],
                       "drink": [199, 200, 201, 202, 203, 204, 205],
                       "finish": [217, 218, 219, 220, 221], "crouch": [109],
                       "sword": [151], "ready": [151], "attack": [151, 152, 153, 154, 155, 156],
                       "parry": [157, 158], "dead": [185]},
            "guard": {"stand": [151], "ready": [151], "approach": [151, 152], "attack": [151, 152, 153, 154, 155, 156],
                      "parry": [157, 158], "hurt": [172], "dead": [183]}},
        "limitations": ["Frame-to-action sequences and timing above are editable interpretations pending full animation bytecode tracing.",
                        "Original OAM clipping/scanline sprite limits and background-priority occlusion are not simulated in these bitmap previews.",
                        "Only the standard guard combat pointer subset151..183 is exported; alternate story/skeleton contexts need additional branch state.",
                        "Malformed or unresolved original frame entries are explicitly excluded or flagged; pixels are never substituted."],
        "shared_chr": {"destination_start": 0x0400, "source_bank_base": 3,
                       "graphics_wordlist_cpu_address": 0xA2C1,
                       "slot_count": len(extraction.shared),
                       "tiles": [{"chr_slot": slot, **{k: v for k, v in tile.items() if k != "pixels"}}
                                 for slot, tile in extraction.shared.items()]},
        "frames": frames, "errors": errors,
        "counts": {"frames": len(frames), "actors": dict(Counter(f["actor"] for f in frames)),
                   "complete_frames": sum(f["status"] == "recovered" for f in frames),
                   "errors": len(errors)}}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, separators=(",", ":")) + "\n")
    args.preview.parent.mkdir(parents=True, exist_ok=True)
    previews(frames, args.preview)
    print(json.dumps(result["counts"]))
    print("Explicit unresolved entries:", json.dumps(errors))


if __name__ == "__main__":
    main()
