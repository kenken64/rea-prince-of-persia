/**
 * Observation of the unchanged original ROM; independent Wasm game does not use
 * this emulator. Reproduce: npm ci --prefix analysis/validation/original-ledge-emulator
 * then: node tools/original_ledge_verify.mjs
 * PPM captures are portable RGB images. Experiment RAM changes are listed below.
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {root,out,digest,makeNES,state,step,saveFrame} from './original_ledge_runtime.mjs';

const hex=n=>'0x'+n.toString(16).toUpperCase().padStart(4,'0');
const compact=s=>Object.fromEntries(Object.entries(s).filter(([k])=>!['actor_raw','zp_0c_7f','alive_raw'].includes(k)));
// All of the following steps use controller input only, starting at reset.
const baseline=makeNES();
const baselineInputs=[[180,[]],[2,['START']],[180,[]],[2,['START']],[300,[]],
  [20,['START']],[60,[]],[200,['RIGHT']],[130,[]]];
for(const [frames,input] of baselineInputs)step(baseline,frames,input);
const base=baseline.toJSON();
if(state(baseline).actor_x!==53||state(baseline).actor_y!==128||state(baseline).script!==0x96DE)
  throw Error('Controller-only baseline changed: '+JSON.stringify(compact(state(baseline))));

function experiment(name,ram,inputAt,total,captureAt={}){
  const nes=makeNES();nes.fromJSON(structuredClone(base));
  const diff=[];
  for(const [address,value] of ram){diff.push({address:hex(address),old:nes.cpu.mem[address],value});nes.cpu.mem[address]=value;}
  const entries=[],writes=[],trace=[],captures=[];
  const emu=nes.cpu.emulate.bind(nes.cpu),write=nes.cpu.write.bind(nes.cpu);
  let opcodePC=0;
  nes.cpu.emulate=function(){
    opcodePC=(this.REG_PC+1)&65535;
    if([0xF99E,0xD7DF,0xF882].includes(opcodePC))entries.push({video_frame:nes.observationFrame,
      pc:hex(opcodePC),a:this.REG_ACC,x:this.REG_X,y:this.REG_Y,tile_04b1:this.mem[0x4b1],
      raw_04ca:this.mem[0x4ca],actor:compact(state(nes))});
    return emu();
  };
  nes.cpu.write=function(address,value){
    const old=this.mem[address];write(address,value);
    if([0x60F,0x610,0x611,0x615,0x616,0x617,0x618,0x4b1,0x4ca].includes(address)&&old!==value)
      writes.push({video_frame:nes.observationFrame,pc:hex(opcodePC),address:hex(address),old,value});
  };
  for(let i=1;i<=total;i++){
    step(nes,1,inputAt(i));trace.push(compact(state(nes)));
    if(captureAt[i]){
      const file=saveFrame(nes,name+'-'+captureAt[i]);
      captures.push({video_frame:i,file:path.relative(root,file),actor:compact(state(nes))});
    }
  }
  const transitions=trace.filter((s,i)=>i===0||['actor_x','actor_y','metasprite','action','motion_mode_raw','script'].some(k=>s[k]!==trace[i-1][k]));
  return {name,controlled_ram_initialization:diff,input_schedule:Array.from({length:total},(_,i)=>inputAt(i+1)),entries,writes,trace,transitions,captures};
}

// Seed only falling state. The original collision code decides if/where to catch.
const fall=[[0x60F,152],[0x610,0],[0x611,110],[0x613,0x4E],[0x614,0x99],
  [0x615,0],[0x616,7],[0x617,105],[0x618,3]];
const scenarios=[];
scenarios.push(experiment('catch-left',fall,()=>['A'],220,{7:'frame91',43:'swing',191:'end'}));
scenarios.push(experiment('catch-release',fall,i=>i<=9?['A']:[],45,{7:'frame91',15:'release'}));
scenarios.push(experiment('catch-climb-left',fall,i=>i<=9?['A']:i<=69?['UP']:[],80,
  {7:'frame91',35:'frame140',39:'frame141',67:'frame149',71:'standing'}));

// Separately seeded right-facing hang tests the mirrored climb placement.
// It is not evidence that an actual grab is possible at this specific location.
const hang=[[0x60F,121],[0x610,0],[0x611,127],[0x613,0xA5],[0x614,0x98],
  [0x615,255],[0x616,9],[0x617,91],[0x618,2],[0x4ca,3]];
scenarios.push(experiment('climb-right',hang,i=>i<=60?['UP']:[],70,
  {27:'frame140',31:'frame141',59:'frame149',63:'standing'}));

for(const s of scenarios){
  fs.writeFileSync(path.join(out,'original-ledge-'+s.name+'-trace.json'),JSON.stringify(s,null,2));
  console.log(s.name,JSON.stringify(s.transitions.map(({frame,actor_x,actor_y,action,metasprite,motion_mode_raw,script})=>
    ({frame,x:actor_x,y:actor_y,action,metasprite,mode:motion_mode_raw,script:hex(script)}))));
}
const packageLock=fs.readFileSync(path.join(out,'original-ledge-emulator/package-lock.json'));
fs.writeFileSync(path.join(out,'original-ledge-runtime-verification.json'),JSON.stringify({
  rom_sha256:digest,rom_patched:false,emulator:{name:'jsnes',version:'2.1.0',emulateSound:false,
    package_lock_sha256:crypto.createHash('sha256').update(packageLock).digest('hex')},
  delivered_game_uses_emulator:false,
  baseline:{controller_only:true,input_schedule:baselineInputs.map(([frames,input])=>({frames,input})),state:compact(state(baseline))},
  field_definitions:{'060F/0610':'16-bit actor anchor X','0611':'actor anchor Y','0613/0614':'animation script pointer',
    '0615':'facing: FF right, 00 left, proved by controller-only trace',
    '0616':'action selector','0617':'metasprite frame','0618':'motion mode, not an alive boolean'},
  findings:[
    {id:'runtime-catch',kind:'observed-original-CPU',experiment:'catch-left',
      observation:'A-held controlled fall enters fixed-bank F99E and D7DF at video frame3, A=56 X=63, below-cell04B1=13. Actor anchor changes152,110 to152,127; mode2/action9 selects98A5; frame91 appears at video frame6.',
      formula_corroborated:'LEFT X=32*ledge_column+56 and Y=64*ledge_row+127; ledge column3,row0.',
      source_addresses:['0xF99E','0xD7DF','bank2:0xAE99'],
      note:'04CA is cleared by original code before these entries; 04B1 retains the below-cell.'},
    {id:'runtime-climb-alignment',kind:'observed-original-CPU',experiments:['catch-climb-left','climb-right'],
      observation:'UP selects action10/script990F, first aligns to LEFT154,128 or RIGHT120,128. At D7DF, LEFT A=58 X=64; RIGHT A=24 X=64, with04B1=13.',
      formula_corroborated:'Before climb: LEFT X=32*column+58; RIGHT X=32*column+24; Y=64*ledge_row+128.'},
    {id:'runtime-climb-frames',kind:'observed-original-CPU',experiments:['catch-climb-left','climb-right'],
      observation:'Frames135,136,137,138,139,140,141,142,143,144,145,146,147,149,15 appear four video frames apart; 148 never appears.',
      original_script:'bank5:0x990F',
      anchor_change_before141:{right:{dx:10,dy:-63},left:{dx:-10,dy:-63}},
      terminal_anchor_change:{right:{dx:2,dy:0},left:{dx:-2,dy:0}},
      write_instructions:{right_x:'bank5:0x84ED',left_x:'bank5:0x84CE',y:'bank5:0x8545'}},
    {id:'runtime-held-button',kind:'observed-original-CPU',experiment:'catch-left',
      observation:'Holding A preserves the finite98A5 hanging swing, at X152,Y127, for43 displayed swing steps (47 logical animation steps including the terminal settling sequence); original code then selects83,84,85,15 via992D. Holding A does not prove an infinite hanging loop.',
      additional_evidence:'original-ledge-forced-hang-cases.json separately records A, B and A+B behavior from directly initialized hanging state.'},
    {id:'runtime-release',kind:'observed-original-CPU',experiment:'catch-release',
      observation:'Release A after video frame9: action11/script992D by frame12, then83 at14,84 at18,85 at22,15 at26. This location has supporting floor below, so Y remains127; do not generalize that release never falls.'},
    {id:'runtime-facing',kind:'observed-controller-only',artifact:'original-ledge-facing-proof.json',
      observation:'RIGHT gives0615=FF while anchorX increases; LEFT gives0615=00 while anchorX decreases. No actor RAM initialization was used in this facing experiment.'}
  ],
  experiments:scenarios.map(s=>({name:s.name,trace_file:'original-ledge-'+s.name+'-trace.json',
    controlled_ram_initialization:s.controlled_ram_initialization,captures:s.captures})),
  limitations:['RAM-seeded experiments validate original code paths and animation, not a complete unassisted playthrough.',
    'PPU framebuffer captures may trail RAM changes by a video frame; capture metadata preserves the observed state.',
    'Emulator observations are not a hardware timing certification. Audio emulation was disabled.',
    'Catch and release geometry is specific to Level1 room1 in these experiments.']
},null,2));
