#!/usr/bin/env python3
"""Recover original NES color IDs and bounded background attribute rules.

Palette bytes come from the exact user ROM. RGB conversion is the separately
identified, unmodified FCEUX default palette, never sampled screenshot colors.
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parents[1]
ROM_SHA = "5f14d4d31cc588ddcdfb2b4d46eb7051b06d02655c9208037ef7ae137c4740e4"
RGB_SHA = "bbb0355bcadc4be771efeb81930b09b17d97dcb8c70167a652902a789158c5f8"


def rom_offset(bank, address):
    return 16 + 16384 * bank + address - (0xC000 if bank == 7 else 0x8000)


def attribute_address_and_mask(ppu_address):
    """B28A's result: nametable attribute byte address and affected quadrant."""
    nt = ppu_address & 0x2C00
    position = ppu_address & 0x3FF
    tile_x, tile_y = position & 31, position >> 5
    address = nt + 0x3C0 + (tile_y // 4) * 8 + tile_x // 4
    shift = ((tile_y & 2) << 1) | (tile_x & 2)
    return address, 3 << shift


def extract(rom, rgb_bytes):
    assert hashlib.sha256(rom).hexdigest() == ROM_SHA, "Unsupported ROM revision"
    assert len(rgb_bytes) == 192 and hashlib.sha256(rgb_bytes).hexdigest() == RGB_SHA, "Unexpected RGB profile"
    rgb64 = [list(rgb_bytes[i:i+3]) for i in range(0, 192, 3)]
    hex64 = ["#" + rgb_bytes[i:i+3].hex() for i in range(0, 192, 3)]

    def word(bank, address):
        return struct.unpack_from("<H", rom, rom_offset(bank, address))[0]

    def sequence(address):
        frames = []
        cursor = address
        while True:
            pointer = word(2, cursor)
            if pointer == 0xFFFF:
                break
            assert 0x8000 <= pointer <= 0xBFE0
            raw = list(rom[rom_offset(2, pointer):rom_offset(2, pointer) + 32])
            assert len(raw) == 32 and all(value < 64 for value in raw)
            frames.append({"source_cpu_address": hex(pointer), "source_file_offset": rom_offset(2, pointer),
                           "indices32": raw, "background": [raw[i:i+4] for i in range(0, 16, 4)],
                           "sprites": [raw[i:i+4] for i in range(16, 32, 4)],
                           "rgb32": [rgb64[v] for v in raw]})
            cursor += 2
            assert len(frames) <= 32
        return {"sequence_cpu_address": hex(address), "sequence_file_offset": rom_offset(2, address),
                "terminator_cpu_address": hex(cursor), "frames": frames}

    levels = []
    unique_palettes = {}
    for i in range(14):
        pointer = word(2, 0xB6A4 + 2 * i)
        seq = sequence(pointer)
        assert len(seq["frames"]) == 1
        palette = seq["frames"][0]
        unique_palettes[palette["source_cpu_address"]] = palette
        levels.append({"number": i + 1, "level_index": i,
                       "pointer_table_file_offset": rom_offset(2, 0xB6A4 + 2*i),
                       **seq, **palette})
    backgrounds = []
    for i in range(16):
        ptr = word(4, 0xA45E + 2*i)
        f = rom_offset(4, ptr)
        raw = list(rom[f:f+9])
        pattern = raw[3]
        backgrounds.append({"pattern_id": i, "source_cpu_address": hex(ptr), "source_file_offset": f,
                            "header_raw": raw, "width_tiles": raw[0], "height_tiles": raw[1],
                            "ppu_tile_offset": raw[2], "attribute_fill_pattern": pattern,
                            "attribute_quadrant_palettes": [(pattern >> shift) & 3 for shift in (0, 2, 4, 6)],
                            "render_fields_raw": raw[4:]})
    assert backgrounds[0]["header_raw"][:4] == [1, 2, 0x45, 0xAA]
    assert backgrounds[11]["header_raw"][:4] == [1, 2, 0x45, 0xAA]
    for level in levels:
        assert level["sprites"][1] == [15, 39, 22, 32]
    torch_frames = []
    for frame in range(5):
        pixels, sources = [0] * 128, []
        for half in range(2):
            tile_id = 0x336 + frame * 2 + half
            source = rom_offset(3, 0x8000 + tile_id * 16)
            raw = rom[source:source+16]
            for y in range(8):
                for x in range(8):
                    pixels[(half*8+y)*8+x] = ((raw[y] >> (7-x)) & 1) | (((raw[y+8] >> (7-x)) & 1) << 1)
            sources.append({"bank": 3, "tile_id": tile_id, "source_file_offset": source,
                            "raw_hex": raw.hex(), "sha256": hashlib.sha256(raw).hexdigest()})
        dungeon_map = [rom[rom_offset(4, 0xA220 + frame*2 + i)] for i in range(2)]
        palace_map = [rom[rom_offset(4, 0xA216 + frame*2 + i)] for i in range(2)]
        # Prove dynamic tile numbers refer to these original CHR words in each
        # theme's type19 loaded graphics list. Layout index1 names word0.
        for pointer_table, local_indices in [(0xB0E9, dungeon_map), (0xB043, palace_map)]:
            gfx_list = word(2, pointer_table + 2*19)
            for local, source in zip(local_indices, sources):
                assert word(5, gfx_list + 2*(local-1)) == source["tile_id"]
        torch_frames.append({"frame": frame, "width": 8, "height": 16, "pixels": pixels,
                             "write_mask": [1] * 128, "sources": sources,
                             "dungeon_local_tile_indices": dungeon_map, "palace_local_tile_indices": palace_map})
    rules = {
        "grid_unit_pixels": 16,
        "base_palette": 0,
        "attribute_address": "nametable_base+0x3C0+floor(tile_y/4)*8+floor(tile_x/4)",
        "quadrant_shift": "((tile_y&2)<<1)|(tile_x&2)",
        "masked_write": "new_attribute=(old_attribute & ~(3<<shift)) | (palette_group<<shift)",
        "wall": {"logical_type": 20, "palette_group": 1,
                 "apply_on": "each actual8x8 base-layout nametable write, after that tile write",
                 "layout_columns": [0, 1, 2, 3],
                 "conditions": {"zero_page_005e": 0, "ram_04bc": 0},
                 "ignored_columns": [4, 5, 6],
                 "original_routine": {"bank": 4, "cpu_address": "0xbf30", "file_offset": rom_offset(4, 0xBF30)},
                 "note": "Do not recolor the full56px metatile; the right24px belong to overlapping neighboring cells."},
        "torch": {"logical_type": 19, "palette_group": 2,
                  "dungeon_pattern_id": 0, "palace_pattern_id": 11,
                  "pixel_offset_from_original_cell_ppu_origin": [40, 16],
                  "graphic_size_pixels": [8, 16],
                  "attribute_extent": "one containing16x16 quadrant, shared with any other pixels in that quadrant",
                  "conditions": {"queue_enabled_zero_page_0061": "nonzero", "right_neighbor_type": "not18"},
                  "apply_order": "after static room layout, through the0100 background-object queue",
                  "queue_builder_cpu_range": ["0xe379", "0xe3ab"],
                  "attribute_writer": {"bank": 4, "cpu_address": "0xad56", "file_offset": rom_offset(4, 0xAD56)}},
        "other_dynamic_background_patterns": "Use the header attribute_fill_pattern with the affected quadrant mask. Most patterns use0; patterns0/11 useAA (palette2).",
        "status_region": "Separate setup modifies bottom attribute-row half-quadrants to palette3. Gameplay-grid defaults apply above the status strip.",
        "context_note": "E533 returns the neighboring cell TYPE; zero-page59 is a tile overlay selector, not a palette index."}
    evidence = []
    for name in ["upload", "copy32", "selector", "attribute-writer", "attribute-address", "below-tile",
                 "attribute-clear", "gameplay-attribute-clear", "background-queue", "background-render"]:
        p = ROOT / f"analysis/rea/palette-{name}.json"
        if p.exists():
            obj = json.loads(p.read_text())
            if obj.get("evidence_id"):
                evidence.append({"file": str(p.relative_to(ROOT)), "evidence_id": obj["evidence_id"],
                                 "procedure": obj.get("raw_result", {}).get("value", {}).get("procedure", {}).get("address")})
    comparison_path = ROOT / "analysis/rea/palette-reference-profile-comparison.json"
    return {"schema": "pop-nes-original-palettes-v1", "rom_sha256": ROM_SHA,
            "rgb_profile": {"name": "FCEUX default (FCEU0.12 and earlier), unmodified192-byte .pal",
                            "source": "https://raw.githubusercontent.com/TASEmulators/fceux/master/output/palettes/FCEUX.pal",
                            "documentation": "https://fceux.com/web/help/PaletteOptions.html", "sha256": RGB_SHA,
                            "normal_emphasis_bits": 0, "rgb_values_are": "display conversion choice, not RGB values stored in the NES ROM"},
            "rgb64": rgb64, "hex64": hex64,
            "palette_table": {"bank": 2, "cpu_address": "0xb6a4", "file_offset": rom_offset(2, 0xB6A4),
                              "entry_count": 14, "entry_size": 2,
                              "format": "level->FF FF-terminated list of32-byte palette pointers"},
            "upload": {"bank": 2, "cpu_address": "0xb63c", "destination_ppu": "0x3f00", "byte_count": 32,
                       "source_pointer": "0017/0018", "sequence_pointer": "004D/004E", "sequence_offset": "007D",
                       "enabled": "007E nonzero", "intro_override": "0735 nonzero selects level-index0 pointer"},
            "levels": levels, "unique_palettes": list(unique_palettes.values()),
            "additional_sequences": [sequence(0xB6D8), sequence(0xB7EE)],
            "sprite_palette_assignment": {"player_group": 1, "player_indices": [15, 39, 22, 32],
                                          "proof": "Normal player frame15 record bank4:82F8 has OAMattribute01 at headerbyte5; B407/B40A copies this toRAM38; B49C frame writer emitsRAM38.",
                                          "guard_group": 2,
                                          "guard_group_status": "proven normal guard body; individual frame-part attributes remain authoritative",
                                          "guard_proof": "Alternate guard frame151 indexes bank4 record87E6 [01,FF,FE,04,05,02,CB,98], OAMattribute02 at byte5.",
                                          "guard_secondary_part_group": 1,
                                          "guard_secondary_proof": "Record87EE [00,FE,F9,01,02,01,D0,BF] emits sword with OAMattribute01."},
            "background_attribute_rules": rules, "animated_background_headers": backgrounds,
            "torch_animation": {"frame_count": 5, "width": 8, "height": 16,
                                "pixel_format": "row-major indices0..3", "background_palette_group": 2,
                                "origin_offset_pixels": [40, 16], "zero_color_is": "universal background; tiles are written in full",
                                "dungeon_frame_pointer_list": "bank4:A2BA", "palace_frame_pointer_list": "bank4:A2C6",
                                "frame_driver": "bank4:AF88 follows cached background records and word lists; FFFF loops frame list",
                                "phase_state": {"dungeon_initial_phase": "one-based torch ordinal in0100 queue order",
                                                "palace_initial_phase": 0, "lookup": "use oldphase to index frame pointer list, then increment phase",
                                                "ffff_loop": "setphase=1 and restart lookup in same call",
                                                "recurring_frame_indices": [1, 2, 3, 4],
                                                "frame0": "used when initializedphase0; not the repeating loop target"},
                                "timing": "frame order is recovered; outer-call timing is not measured here",
                                "frames": torch_frames},
            "runtime_palette_overrides": [
                {"routine_bank": 2, "routine_cpu_address": "0xb613", "condition": "06EF nonzero; routine resets06EF",
                 "destination_ppu": "0x3f18", "indices": [15, 48, 32, 15], "meaning": "temporary sprite-group2 replacement; triggering gameplay state is not traced here"},
                {"routine_bank": 5, "routine_cpu_address": "0x805c", "destination_ppu": "0x3f00",
                 "condition": "06DC countdown and04D5 selector", "possible_indices": [15, 22, 51, 54, 55],
                 "meaning": "temporary universal-background flash; timing not reconstructed by this export"}],
            "reference_profile_comparison": json.loads(comparison_path.read_text()) if comparison_path.exists() else None,
            "rea_evidence": evidence,
            "validation": {"all14_palette_lists_have_one32_byte_frame": True,
                           "all_original_color_ids_below64": True, "all14_player_quartets_match": True,
                           "raw_bytes_from_exact_rom": True, "rgb_profile_sha256_verified": True},
            "limitations": ["A background palette applies per16x16 attribute quadrant, never independently per object or pixel.",
                            "Attribute rules here cover the normal static room pass and identified background-object queue; full dynamic screen state is not emulated.",
                            "Sprite palette selection must use each original OAM/frame attribute byte; group1 is proven for normal player frames.",
                            "PPUMASK emphasis/grayscale and analog/composite video effects are not applied by this normal RGB conversion.",
                            "The supplied screenshot selects a documented RGB profile; original colors remain the recovered ROM indices."]}


def write_findings(result):
    by_name = {Path(r["file"]).stem.removeprefix("palette-"): r for r in result["rea_evidence"]}
    observations = [
        {"finding": "B68A selects the level's sequence from14 little-endian pointers at bank2:B6A4, using2*RAM70;0735 nonzero forces index0.", "evidence": by_name.get("selector")},
        {"finding": "B63C reads the sequence word through4D/4E+7D. FFFF resets7D/7E; otherwise setsPPUADDR3F00 and callsB67C, then advances7D by2.", "evidence": by_name.get("upload")},
        {"finding": "B67C initializesY=0/X=20hex, copies exactly32 bytes from(0017),Y toPPUDATA2007 and returns.", "evidence": by_name.get("copy32")},
        {"finding": "The normal14 level sequences each contain one32-byte palette. Six distinct tables are used. Player sprite-group1 is0F271620 in all14.", "method": "exact ROM pointer/data extraction with SHA-bound offsets"},
        {"finding": "Bank5:831C sets lowPPUADDR=C0 and writes7*8 zero bytes. Callers provide high23/27, clearing normal gameplay attributes to palette0.", "evidence": by_name.get("gameplay-attribute-clear")},
        {"finding": "Bank4:BF30 is called after each E723 base-layout tile write. Normal flags5E=0/04BC=0, Xremaining>=4 andlogicaltype20 cause a masked attribute update using55hex, selecting palette1 for the wall's first32px only.", "evidence": by_name.get("attribute-writer"), "caller_evidence": "analysis/rea/graphics-function-e723.json"},
        {"finding": "Bank4:B28A computes the attribute address and16x16 quadrant mask for a nametable tile address. Palette writes preserve the other three quadrants.", "evidence": by_name.get("attribute-address")},
        {"finding": "Bank4:AD56 reads0100 background-queue records; patternID&3F selects a9-byte header viaA45E. Headerbyte3 is the attribute fill pattern, applied by read/modify/write withB28A's quadrantmask.", "evidence": by_name.get("background-queue")},
        {"finding": "Fixed codeE379..E3AB queues pattern0 for dungeon torchtype19 and pattern11 for palace, when61 is enabled and the next tile is not18. Both headers are1x2 tiles at offset45hex, attrAAhex:8x16 flame at originalcell+(40,16), palette2.", "method": "exact fixed-ROM byte decoding, corroborated by graphics-function-e11d.json and AD56 header parsing", "caller_evidence": "analysis/rea/graphics-function-e11d.json"},
        {"finding": "DungeonA2BA andpalaceA2C6 each list five frame-data pointers. Relative tile numbers49..52 or30..39 resolve through their theme's type19 graphics lists to the identical bank3 tileIDs336..33F. All5 frames are exported8x16 indexed pixels with complete tile write masks.", "method": "independent original word-list and CHR-bitplane extraction; all10 tile mappings asserted", "source_file_offsets": [rom_offset(3, 0x8000+0x336*16), rom_offset(3, 0x8000+0x340*16)], "renderer_evidence": by_name.get("background-render")},
        {"finding": "E533 reads the TYPE of the cell below, including neighbor-room handling. RAM59 feeds context tile overlays, not color-palette selection.", "evidence": by_name.get("below-tile")},
        {"finding": "Normal player body usesOAMpalette1; normalguardbody uses2 and its swordpart uses1. Preserve each individual part's original attribute byte.", "method": "exact original frame-header evidence recovered by actor agent", "details": result["sprite_palette_assignment"]},
        {"finding": "The unmodified official FCEUX RGB profile was selected by comparison after converting the screenshot's Display ICC profile to sRGB. Weighted nearest-color squared error18.41 forFCEUX versus402.70 NestopiaYUV and986.23 NestopiaRGB. No sampled screenshotRGB enters the palette data.", "details": result["rgb_profile"], "comparison": result["reference_profile_comparison"]}]
    extra = {"schema": "pop-nes-palette-findings-v1", "rom_sha256": ROM_SHA,
             "palette_export": "analysis/graphics/palettes.json", "observations": observations,
             "reproduction": "python3 tools/extract_palettes.py", "limitations": result["limitations"],
             "background_rules": result["background_attribute_rules"],
             "validation": result["validation"],
             "derived_target_mapping": "palette-*entry.bin files seed exact switched-bank tails followed by fixedbank7; earlier selected-bank addresses may be unmapped. No target bytes are modified.",
             "failed_probe_retained": "palette-selector-unseeded.json has missing-function error; the explicit B68A-seeded probe succeeds. Initial AF89 probe begins one byte after the AF88 entry and is excluded from findings; its artifact is retained as palette-background-render-offset89.json."}
    (ROOT / "analysis/rea/palette-findings.json").write_text(json.dumps(extra, indent=2) + "\n")


def write_background_animations(rom, result):
    """Decode AF88's original frame maps against the active type graphics list."""
    def word(bank, a):
        return struct.unpack_from("<H", rom, rom_offset(bank, a))[0]
    # E3C9/E44C/E498 use BNE, so nonzero palace retains the initial Y;
    # zero dungeon executes the following LDY. Torch uses BEQ instead.
    bindings = {0: ("dungeon", 19), 11: ("palace", 19),
                1: ("palace", 18), 2: ("palace", 18), 7: ("dungeon", 18), 8: ("dungeon", 18),
                3: ("palace", 4), 4: ("palace", 4), 12: ("palace", 4), 13: ("palace", 4),
                5: ("dungeon", 4), 6: ("dungeon", 4), 14: ("dungeon", 4), 15: ("dungeon", 4),
                9: ("dungeon", 2), 10: ("palace", 2)}
    frames, patterns = {}, []
    source_tiles = {}
    for header in result["animated_background_headers"]:
        pattern = header["pattern_id"]
        theme, typ = bindings[pattern]
        table = 0xB0E9 if theme == "dungeon" else 0xB043
        gfx = word(2, table + typ * 2)
        gfx_words = []
        cursor = gfx
        while word(5, cursor) != 0xFFFF:
            gfx_words.append(word(5, cursor)); cursor += 2
        w, h = header["width_tiles"], header["height_tiles"]
        frame_list = header["header_raw"][7] | header["header_raw"][8] << 8
        frame_ids = []
        for frame_index in range(128):
            ptr = word(4, frame_list + 2 * frame_index)
            if ptr in (0xFFFF, 0xFEFF):
                terminator = ptr
                break
            assert 0x8000 <= ptr <= 0xC000 - w*h
            key = f"{theme}-{ptr:04x}-{w}x{h}"
            frame_ids.append(key)
            if key in frames:
                continue
            raw_map = list(rom[rom_offset(4, ptr):rom_offset(4, ptr)+w*h])
            pixels, mask = [0] * (w*h*64), [0] * (w*h*64)
            used = []
            for cell, local in enumerate(raw_map):
                # B1B8's PPU writer: FE skips; FF writes blankCHR0; zero
                # preserves the nametable for wide(spike) rows, blanks narrow rows.
                write = local != 0xFE and (local != 0 or w < 4)
                tile = [0] * 64
                if local not in (0, 0xFE, 0xFF):
                    assert 1 <= local <= len(gfx_words), (pattern, frame_index, local, len(gfx_words))
                    source_id = gfx_words[local-1]
                    assert 0 < source_id < 1024
                    off = rom_offset(3, 0x8000 + source_id*16)
                    data = rom[off:off+16]
                    source_tiles[str(source_id)] = {"bank": 3, "tile_id": source_id, "source_file_offset": off,
                                                   "raw_hex": data.hex(), "sha256": hashlib.sha256(data).hexdigest()}
                    used.append({"map_cell": cell, "local_tile_index": local, "source_tile_id": source_id})
                    tile = [((data[y] >> (7-x)) & 1) | (((data[y+8] >> (7-x)) & 1) << 1)
                            for y in range(8) for x in range(8)]
                for y in range(8):
                    for x in range(8):
                        dst = ((cell//w)*8+y)*(w*8)+(cell%w)*8+x
                        pixels[dst], mask[dst] = tile[y*8+x], int(write)
            frames[key] = {"id": key, "width": w*8, "height": h*8, "pixels": pixels, "write_mask": mask,
                           "map_bank": 4, "map_cpu_address": ptr, "map_file_offset": rom_offset(4, ptr),
                           "map_raw": raw_map, "source_tiles": used}
        else:
            raise ValueError("Unterminated background frame list")
        offset = header["ppu_tile_offset"]
        patterns.append({"pattern_id": pattern, "theme": theme, "logical_type": typ,
                         "width": w*8, "height": h*8,
                         "origin_offset_pixels": [(offset&31)*8, (offset>>5)*8],
                         "attribute_fill_pattern": header["attribute_fill_pattern"],
                         "palette_group": header["attribute_fill_pattern"] & 3,
                         "initial_phase_raw": header["header_raw"][4],
                         "header": header, "graphics_list_cpu_address_bank5": gfx,
                         "graphics_list_file_offset": rom_offset(5, gfx),
                         "frame_pointer_list_cpu_address_bank4": frame_list,
                         "frame_ids": frame_ids, "terminator": terminator})
    output = {"schema": "pop-nes-background-animations-v1", "rom_sha256": ROM_SHA,
              "pixel_format": "row-major indices0..3; write_mask marks complete nametable tile writes, including color0",
              "patterns": patterns, "frames": frames, "source_tiles": source_tiles,
              "normal_bindings": {"dungeon": {"torch": 0, "spikes": 9, "chomper": 7, "chomper_left_pillar": 8,
                                                "gate": 5, "gate_upper_neighbor_variant": 14},
                                  "palace": {"torch": 11, "spikes": 10, "chomper": 1, "chomper_left_pillar": 2,
                                              "gate": 3, "gate_upper_neighbor_variant": 12}},
              "queue_crop_flags": {"raw_parameter_40": "maps to cachedflags20; AF88 reduces output row width by3",
                                   "raw_parameter_80": "maps to cachedflags40; AF88 reduces output row width by3, special-casewidth2",
                                   "export": "full header/map dimensions preserved; cropped edge-state compositing is not synthesized"},
              "terminator_behavior": {"65535_FFFF": "set cachedphase1 and retry lookup; used by torch loop",
                                      "65279_FEFF": "stop this update and undo phase increment, holding the sentinel phase until gameplay changes it",
                                      "initial_phase": "Headerbyte4 is preserved exactly; some initial phases deliberately point beyond the first list's terminator into a neighboring stop marker. Select visible state from gameplay, not initial_phase as a frame_ids index."},
              "inferred_state_labels": {"gate_frame0": "appears fully extended", "gate_final_frame": "appears raised; exact state-to-phase mapping still required"},
              "evidence": result["rea_evidence"],
              "validation": {"all16_frame_lists_terminated": True, "all_pixel_sources_asserted_from_original_graphics_lists": True,
                             "unique_frames": len(frames), "distinct_source_chr_tiles": len(source_tiles)},
              "limitations": ["Frame pointer order and graphic pixels are recovered; gameplay timing and current-state selection are not fully reconstructed.",
                              "Raw0/FE/FF tokens are retained. Wide rows preserve0, narrow rows blank0; FE skips and FF blanks.",
                              "Edge-neighbor flags can crop maps; full maps are exported with crop flags documented.",
                              "Potions/swords are sprite entities and are exported separately in actor-frames.json; loose-floor fall motion is not encoded by these16 background headers."]}
    (ROOT / "analysis/graphics/background-animations.json").write_text(json.dumps(output, separators=(",", ":")) + "\n")
    print(f"Decoded16 background patterns /{len(frames)} unique frames /{len(source_tiles)} originalCHR sources")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--rom", type=Path, default=ROOT / "analysis/rom/Prince of Persia (USA).nes")
    ap.add_argument("--rgb-profile", type=Path, default=ROOT / "analysis/rea/palette-FCEUX.pal")
    ap.add_argument("--out", type=Path, default=ROOT / "analysis/graphics/palettes.json")
    args = ap.parse_args()
    result = extract(args.rom.read_bytes(), args.rgb_profile.read_bytes())
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, indent=2) + "\n")
    write_findings(result)
    write_background_animations(args.rom.read_bytes(), result)
    print(f"Recovered{len(result['levels'])} level palettes / {len(result['unique_palettes'])} distinct32-byte palettes; FCEUX RGB profile SHA verified.")


if __name__ == "__main__":
    main()
